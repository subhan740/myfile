a=int(input('enter a no')
      
    for i in range(5)
       print(i)
