#s='aaaaaaabbbbbcccccddd'
#previous=s[0]
#output=''
#c=1
#
#i=1
#while i<len(s):
#    if s[i]==previous:
#        c=c+1
#    else:
#        output+=str(c)+previous
#        previous=s[i]
#        c=1
#if i==len(s)-1:
#    output+=str(c)+previous 
#    i=i+1
##print(output) 
#
#def fun(x,y):
#    
#    a=x-y
#    b=x+y
#    c=x*y
#    d=x/y
#    return a,b,c,d
#x=int(input('enter x val:'))
#y=int(input('enter y val:'))
#
#result=fun(x,y)
#print(result)
#for i in result:
#     print(i)

#how to chechk that any key present or not in dictionary

