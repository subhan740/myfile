
'''ERROR
1. Compile time error(eg. syntactical errors missing(:), wrong spelling) 2. Logical error(wrong o/p) 
3. Runtime error(Divide by Zero) 4.Syntax error 5.
'''

#a=9
#b=0
#print(a/b)       #####it will show  ZeroDivisionError: division by zero
#print('BYE')

#####HANDLE THE EXCEPTION

#a=9
#b=0
#try:
#    print(a/b)     
#except Exception:
#    print('Hey you cannot devide a no. by zero')    
#print('BYE')

#
#
#a=9
#b=2
#try:
#    
#    print('resource open:')
#    print(a/b) 
#    k=int(input('enter a no.'))         #if u enter a string ,it give value error
#    print(k)
#except ZeroDivisionError as e:
#    print('Hey you cannot devide a no. by zero',e)    
#except ValueError as e:
#    print('invalid input')
#except Exception as e:
#    print('Something Went wrong')  
#    
#finally:
#    print('resource closed')    
#print('BYE')
#
