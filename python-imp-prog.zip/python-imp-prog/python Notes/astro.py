# -*- coding: utf-8 -*-
"""
Created on Sat Jan 19 17:16:24 2019

@author: pythor
"""
'''
Identifiers >> var, class, module, func, or 
any other object in python

A-Z , a-z, _, _12, _a1, d7

% $ # @ & * 2, etc
'''

#a=90
#print(a)
#print(type(a))
#
#c=90.67
#print(c,type(c))
#
#b=3+78j
#print(b,type(b))


'''multiple assignment'''

#a=b=c=10
#print(a,b,c)
#
#a,b,c=2,5,7
#print(a)
#print(b)
#print(c)


#A=90
#print(A)
#
#_1=90
#print(_1)
#
#_a1=67
#print(_a1)
#
#_=90
#print(_)
#
#a23=30
#print(a23)



'''
OPERATORS

> Arithmetic Op. (+,-,/,*,%,//,**)
> assignment =, +=, -=, /=, *=, //=, **=, %=

boolean type (True:1 , False:0)

> comparission (>, <, >=, <=, ==, !=)
> logical operators and, or, not
> membership op. in, not in
> identity op. is, is not
> Bitwise op. & , |
'''
#a=3
#b=10
#a+=b
#print(a)
#print(b)


#if 9>5:
#    print('true')
#elif 3!=3:
#    print('hello')
#elif 5!=5:
#    print('omega')
#else:
#    print('false')



'''data type conversion'''


int()
float()
complex()
str()
list()
tuple()
dict()
set()
frozenset()


#a=int(input('enter a number: '))
#print(a,type(a))
#if a%2==0:
#    print(a,'is even')
#else:
#    print(a,'is odd')

#if 9==9 or 7<5:
#    print('hello world')
#else:
#    print('goal')

#age=20
#if age<18:
#    print('you cannot drive the car')
#else:
#    print('drive a car')

#a="hello world"
#print(a)
#print(type(a))
#print('h' in a)
#print('g' in a)
#print('h' not in a)
#
#print(9 is 9)
#print(10 is not 67)
#print(9==9)
#
#print(bin(20))

#a=50
#b=67
#print(a,bin(a))
#print(b,bin(b))
#
##.......128 64 32 16 8 4 2 1
##00110010
#print(a&b,bin(a&b))
#print(a|b,bin(a|b))
'''
0011 0010
0100 0011
0111 0011
'''
#a=60
##print(bin(a))
#b=15
##print(bin(b))
#print(a&b,bin(a&b))
#print(a|b,bin(a|b))

'''
NUMBER DATA TYPES
> Number data type stores numeric values
> INTEGERS : int()
> FLOAT : float()
> COMPLEX : complex()
> Not iterable
> Immutable (unchangeable)
'''
#
#a=7
#print(a,type(a))
#
#a=89
#print(a,type(a))
#
#b=67.78
#print(b,type(b))
#
#c=8+78j
#print(c,type(c))

#import math
##print(dir(math))
#print(math.ceil(23.78))
#print(math.floor(23.78))
#print(math.factorial(5))
#print(math.sqrt(25))

"""
Strings
> Iterable
> Ordered
> Sequential
> Immutable (unchangeable)
"""

#a="world"
#print(a,type(a))
##print(a[1:3])
#print(a[2])
#a="universe"
#print(a)
#print(a[-7:-4])
#print(a,type(a))
#print(a[3])
#print(a[1:6])
#print(a[::])
#print(a[2:])
#print(a[:5])
#print(a[::2])
'''
INDEXING & SLICING
'''

#a='UNIVERSE'
#  -87654321
#print(a)
#print(a[::-1])
#print(a[3])
#print(a[-5])
#print(a[1:6])
#print(a[-7:-3])
#print(a[::])
#print(a[3::2])
#print(a[1:-2:3])
'''
built-in methods
'''

#a='UNIVERSE'
##print(len(a))
#print(a.capitalize())
###print(a[-8:5])
#print(a.count('E'))
#print(a.lower())
#print(a.upper())
#print(a.isupper())
##a='hello'
#print(a.islower())
#print(a.isalnum())
#print(a.isalpha())
#print(a.isdigit())

'''
string formatting
%d : decimal
%f : float
%s : string
'''
#a=23
#b=45
#c=a+b
#print('the sum of a & b is c')
#print('the sum of %d & %d is %d'%(a,b,c))
#print('the sum of {0} & {1} is {2}'.format(a,b,c))


#a=','
#b='abc123'
#print(a.join(b))

#a='I am python coder'
#print(a.split('o'))
#print(a.split())

#a='*****hello*****'
#print(a.lstrip('*'))
#print(a.rstrip('*'))
#print(a.strip('*'))

#a='hello'
#b='world'
#c=a+b
#print(c)
#print(b*3)

'''
LIST DATA TYPE []
> Iterable
> Mutable (Changeable)
> Ordered
> Sequential
'''
#x='2345'
#print(x,type(x),x[2])
#a=['c','c++','perl',23,'python','julia','cobol',67]
#print(a)
#print(type(a))
#print(a[3],type(a[3]))
#print(len(a))
#print(a[3])
#print(a[1:4])
#
#b=['lotus','java','java','unix','java']
#c=a+b
#print(c)
#print(b*2)

'''
built in methods
'''
#b.append('julia')
#print(b)
#b=['lotus','java','julia','java','unix','cobol']
#b.pop()
#print(b)
#b.pop(1)
#print(b)
#
#b.insert(1,'python')
#b[1]='python'
#print(b)

#b.remove('java')
#print(b)
#b.clear()
#print(b)

#c=b.copy()
#print(b)
#print(c)
#b.reverse()
#print(b)
#a=['c','c++','julia','python']
#del a[2]
#print(a)
#b=[23,1,33,2,44,3,343,7,56,44,3]
#print(max(b))
#print(min(b))
#b.sort()
#print(b)
#b.sort(reverse=True)
#print(b)
##b.append(a)
#b.extend(a)
#print(b)
#b+=a
#print(b)
#b=b+a
#print(b)

#a=3
#b=7
#c=a+b
##print('the sum of a & b is c')
#print('the sum of {0} and {2} is {1}'.format(a,c,b))
#print('the sum of %d and %d is %d'%(a,b,c))

#%d = decimal
#%f = float
#%s = string

'''
TUPLE ()
> Iterable
> Immutable (Unchangeable)
> Ordered
> Sequential
'''
#a=('c','c++','c++','java',45.23,'perl','lotus','cobol',89)
#print(a)
#print(type(a))
#print(len(a))
#print(a[2],type(a[2]))
#print(a.count('c++'))
#print(a[7])
#print(a[:3:2])
#print(type(a))
#print(a.count('c++'))
#a.append('hello')
#print(a)
#print(len(a))
#b=('kilo',455,23,11,'grams')
#b[1]='immutable'
#print(b)
#del b[2]
#a=a+b
#print(a)
#d=a*2
#print(d)


#x="hello"
#print(x,type(x))
#print(len(x))
#print(x[3])

'''
DICTIONARY  {key1 : value1, key2 : value2}

> Iterable
> Unordered
> Mutable
'''
#a={1:'Aditya',(1,2,3):['python','c','c++'],3:'fifa'}
#print(a)
#print(type(a))
#print(len(a))
#print(a[0])
#print(a[(1,2,3)])
#a.clear()
#print(a)
#print(a.keys())
#print(a.values())
#print(a.items())
#a.pop((1,2,3))
#print(a)
#a.popitem()
#print(a)
#b=a.copy()
#print(b)
#b={1:['kilo','apple'],2:'banana',3:'grapes'}
#print(b)
#b.update({1:['hello','lion']})
#b.update({4:'cherry'})
#print(b)
#import sys
#a=[]
#print(sys.getsizeof(a))
#a.append('aditya')
#print(sys.getsizeof(a))
#
#x=''
#print(sys.getsizeof(1234))

'''
CONDITIONAL STATEMENTS
> if
> else
> elif
'''
#a=int(input('-->>'))
#if a>0:
#    print(a,'is positive')
#elif a==0:
#    print(a,'is zero')
#else:
#    print(a,'is negative')


#a=int(input('enter a number: '))
#if a%2==0:
#    print(a,'is even')
#else:
#    print(a,'is odd')

#
#a=int(input('enter a number: '))
#if a>0:
#    print(a,'is positive')
#elif a==0:
#    print('you have entered zero')
#else:
#    print(a,'is negative')
#print('good bye!')
#

#a=int(input('enter a number: '))
#if a%2==0:
#    if a%3==0:
#        print('BOTH')
#    else:
#        print('only 2')
#else:
#    if a%3==0:
#        print('only 3')
#    else:
#        print('None')


#if a%2==0 and a%3==0:
#    print('both')
#elif a%3==0:
#    print('only 3')
#elif a%2==0:
#    print('only 2')
#else:
#    print('NONE')

'''
LOOPS
'''
#even=[]
#odd=[]
#a=1
#while a<=30:
#    if a%2==0:
#        even.append(a)
#    else:
#        odd.append(a)
#    a+=1
#print('EVEN:',even)
#print('ODD:',odd)


#even=[]
#odd=[]
#for i in range(1,30):
#    if i%2==0:
#        even.append(i)
#    else:
#        odd.append(i)
#print('EVEN:',even)
#print('ODD:',odd)

#a,b=5,7
#a,b=b,a
#print('a-->>',a,'b-->>',b)
#
#a=[3,4,5,6,'hello','c']
#a[0],a[-1]=a[-1],a[0]
#print(a)

#a=6785
#b=str(a)
#c=0
#i=0
#while i<len(b):
#    x=int(b[i])
#    c+=x
#    i+=1
#print(c)


'''
WAP to print odd numbers between 1 to 30.
'''
#even=[]
#odd=[]
#for i in range(1,30):
#    if i%2==0:
#        even.append(i)
#    else:
#        odd.append(i)
#print('EVEN: ',even)
#print('ODD: ',odd)


#[1,4,9,16,25,36,49,64,81,100]

#x=[]
#for i in range(1,11):
#    x.append(i*i)
#print(x)
#a=5
#for i in range(1,a):
#    a*=i
#print(a)

#{1:1,2:4,3:9,4:16,5:25,6:36,7:49,8:64,9:81,10:100}


#a={}
#for i in range(1,11):
#    a.update({i:i*i})
#    print(a)

#for i in range(2000,3201):
#    if i%7==0 and i%5!=0:
#        print(i,end=',')

#print()
#a=int(input('-A->> '))
#b=int(input('-B->> '))

#a,b=23,45
#a,b=b,a
#print('A-->>',a)
#print('B-->>',b)
#
#a=['c','c++','java',23,'perl','python']
#a[0],a[-1]=a[-1],a[0]
#print(a)
#print(type(a[1]))


#print(len(a))
#print(a[0])
#print(a[-1])
#print(a[1:4])
#del a[2]
#print(a)
#a.pop(2)
#a.pop()
#a.append(45)
#print(a)

#flag=0
#while flag<10:
#    print('the current value of flag: ',flag)
#    flag+=1
#print('good bye!!')

#a=1
#while a<=30:
#    if a%2!=0:
#        print(a,end=',')
#    a+=1
#print('yoyo')


#a=1
#while a<=30:
#    if a%2==0:
#        pass
#    else:
#        print(a)
#    a+=1
#print('yoyo')

#[1,4,9,16,25,36,49,64,81,100]

#i=1
#x=[]
#while i<=10:
#    x.append(i*i)
#    i+=1
#print(x)
#a=('c','c++','java',23,'perl','python')
#for i in range(len(a)):
#    print(i,':',a[i])

#a=[]
#for i in range(1,30+1):
#    a.append(i*i)
#print(a)


#a=[]
#for i in range(1,30):
#    if i%2!=0:
#        a.append(i)
#print(a)


#for i in 'python':
#    if i=='h':
#        break
#        print(i)
#    else:
#        print(i)
#print('good bye!')
#
#print()
#
#for i in 'python':
#    if i=='h':
#        continue
#        print(i)
#    else:
#        print(i)
#print('good bye!')
#
#print()
#
#for i in 'python':
#    if i=='h':
#        pass
#        print('pass block',i)
#    else:
#        print(i)
#print('good bye!')


#mutable
#unordered
#doesnt support duplicate items
#iterable

#a={1,3,4,3,2,1,2,'bell','bell',7,7,6,5,5}
#b={5,4,3,2,'uber','ola'}
#print(a)
#print(b)
#print(a&b)
#print(a|b)
#int()
#float()
#complex()
#list()
#tuple()
#dict()
#set()
#a=frozenset({'23',34,2,2,3,4,1,3,2,1})
#print(a)
#b=frozenset([1,2,3,4,5,6,7])
#print(a.intersection(b))
#print(type(a))
#print(len(a))
#print(a[6])
#a.add('goal')
#print(a)
#a.update(('string','world'),[1,2,3,4,5,6,7,8,9,10])
#print(a)
#a.remove(30)
#print(a)
#a.discard(30)
#print(a)
#
#a=570
#for i in range(10,70):
#    if i == a:
#        print('true')
#        break
#else:
#   print('false')


#a=input("Enter the String separated by Hyphen: ").split('-')
#print(a)
#a.sort()
#print(a)
#b='-'.join(a)
#print(b)


