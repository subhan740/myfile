class Category():
    def __init__(self):
        print('Categoris crfeated')
    def sz(self,size):
        self.size=size
        print('size is:',size)
    def brth(self,breath):
        self.breath=breath
        print('Breath is: ',breath)

class Animal():
    def __init__(self):
        print('Animal is created')
    def clr(self,white):
        self.white=white
        print('animal color is: ',white)
    def eat(self):
        print('eatintg')
        
class Dog(Category,Animal):
    def __init__(self):
        print('dog is created')
        Category.__init__(self)
        Animal.__init__(self)
    
    def dog(self):
        print('This is a dog')
    def bark(self):
        print('dog is barking')
        
d=Dog()
d.sz(25)
d.brth('subhan khan')
d.bark()
d.clr('Creamzy white')
d.dog()
d.eat()
       
        
          
    
        
        
        