'''26/03/19         EXCEPTION'''
#try:
#    fh=open('testexcption.txt','w')
#    fh.write('this is my test file for exception!')
#except IOError:
#    print("Error: can\'t find file or read data,IOError")
#except RuntimeError:
#    print('Runtime Error')
#else:
#    print('write content....') 
#fh.close()    
#    

#try:
#    fh=open('testexcption.txt','r')
#    fh.write('this is my test file for exception!')
#except IOError:
#    print("Error: can\'t find file or read data,IOError")
#except RuntimeError:
#    print('Runtime Error')
#else:
#    print('write content....') 
#fh.close()    
#    

'''TRY_FINALLY'''

#try:
#    fh=open('testexcption.txt','r')
#    fh.write('this is my test file for exception! handli g')
#except IOError:
#    print('IOERROR')
#finally:
#    print("Error: cant\'t find file or read data")
#fh.close()    
#    
'''OR etter way   (nested try)'''
#
#try:
#    fh=open('testexcption.txt','r')
#    try:
#        fh.write('this is my test file for exception! handling')
#    finally:
#        print('going to close the file!!!!!')
#        fh.close()
#except IOError:
#    print('IOERROR')
#finally:
#    print("Error: can\'t find file or read data")
##fh.close()  

''' Raising an Exception:::   Raise[Exception [ args ]]'''

#def functionName(level):
#    if level <1:
#        raise Exception(level)
#    return(level) 
#try:
#    l=functionName(-5)
#    print("level=",l)
#except Exception as e:
#    print("error in level argument",e)
#    
  


#assert[expression],[args]  

def KelvinToFarenheit(Temperature):
    assert(Temperature >=0),"Colder than absolute zero"
    return((Temperature-273)*1.8)+32
print (KelvinToFarenheit(273))
print(int(KelvinToFarenheit(505.78)))
#print(KelvinToFarenheit(-5))    
