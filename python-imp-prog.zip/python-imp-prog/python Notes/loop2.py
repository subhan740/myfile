a=1
while a%2==0 and a<=30:
    print('even no')
