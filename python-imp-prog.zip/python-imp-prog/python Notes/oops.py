'''OBJECT: object is the INSTANCE of class
    it is simply collection of data and its functionality, it has state ,property,behaviour,attribute
    by using class we can create many object
    
    CLASS:-class is a template/blueprint to create an object/ (class is a DESIGN & object is REAL WORLD ENTITY)
    class allow us to logically group our data and functions in a way that's easy to reuse 
    class contain variables and methods
    __init__(self,p) :-initialization method use to initialize the Object, it is called automatically
    
    (self) parameter is use to differentiate between instance variable and local variable
    Instance variable:- variable belongs to an object eg self.name=name (here self.name is instance variable
    ans name is local variable)
    CLASS Variable:= variable belongs to a class , to access class variable we need class name as class.variableName'''
    


#######OOPS concept
#class S:
#    clg='SDIET'     #class variable
#    def __init__(self,name,roll):   #method to initialize the object
#        self.name=name
#        self.roll=roll         #instance variable
#    
#    def show(self):      # method to print the msgs
#        print('student Name is:',self.name)
#        print('student roll no is:',self.roll)
#        print('student college:',S.clg)
#        
#student1=S('Subhan Khan',26) #creating object
#student1.show()                  #calling method to display
#
#student2=S('Mehwish',62)
#student2.show()

'''FUNDAMENTAL FEATURES OF OBJECT ORIENTED PROGRAMMING
Inheritance , Encapsulation ,Polymorphism'''


#INHERITANCE

#class employee:
#    def __init__(self,id,name):
#        self.id=id
#        self.name=name
#        
#class company(employee):
#    def display(self):
#        print('employee ID:',self.id,)
#        print('employee name:',self.name)
#emp1=company('1234','Subhan Khan') 
#emp1.display()       
#        

######MULTILEVEL INHERITANCE

#class father:
#    def display(self):
#        print('FATHER')
#        
#class son(father):
#    def show1(self):
#        print('hlo i am the real son')
#        
#class grandson(son):
#    def show2(self):
#        print('hey i am the grand son')
#
#obj=grandson()
#obj.display()
#obj.show1()
#obj.show2()

'''MULTIPLE INHERITANCE
If a new Derive class id derive form more than one base class then it is called Multiple inheritance'''

#class Father:
#    def disp1(self):
#        print('this is the Father class')
#        
#class Mother:
#    def disp2(self):
#        print('this is the Mother class')
#
#class child(Mother,Father):   #here class son derived from father and mother
#    pass
#c=child()
#c.disp1()
#c.disp2()
                
'''ENCAPSULATION
object oriented programming can restrict te access of variables & methods this is called Encapsulation
why use: to prevent data from being modified by accediently so we need to prevent that so...
so there are two types of access spacifier (1) Private (2) public
private method eg: self__updatesoftware()'''
#
#class car:
##    def __init__(self):
##        self.__updatesoftware()    ##private method , can't access out side of the class
#    def drive(self):
#        print('Driving')
#    def __updatesoftware(self):
#        print('Software updating')
#            
#objcar=car()            
#objcar.drive()          ####here obj first call initilzn mthod & intlzn mthd call the private method so...  
#objcar.__updatesoftware()            #hare we can't call update software outside of class if do then give the error            

#OUTPUT: software updating
#         Driving



#PRIVATE VARIABLES

#class car:
#    __maxspeed=0
#    __name=""
#    def __init__(self):
#        self.__maxspeed=200
#        self.__name='supercar'
#    def drive(self):
#        print('Driving')
#        print(self.__maxspeed)
##    def setspeed(self,speed):
##        self.__maxspeed=speed
##        print(self.__maxspeed)
#obj=car()
#obj.drive()
##obj.setspeed(100) 
#obj.__maxspeed=100       ###if we try to modify private variable then can't modified
#obj.drive() 
    

'''POLYMORPHISM  means many form   , one things can take multiple form there are 4 ways to implement polymorphism  
(1)Ductyping (2) operator overloading (3)method overloading (4) Method overriding'''
#class dog:
#    def sound(self):
#        print('bow bow')
#        
#class cat:
#    def sound(self):
#        print('mew mew') 
#        
#def makesound(animaltype):      ####function        
#    animaltype.sound()        # calling method sound by function body
#    
#dogobj=dog()
#catobj=cat()
#makesound(dogobj) 
#makesound(catobj)  ##passing obj in function name 


'''OPERATOR OVERLOADING:::---ASSINING EXTRA WORK TO OPERATORS   we hv different method for different operator
operators remains same but operands change'''

#class student:
#    def __init__(self,m1,m2):
#        self.m1=m1
#        self.m2=m2
#        
#    def __add__(self,other):
#        m1=self.m1+other.m1
#        m2=self.m2+other.m2
#        s3=student(m1,m2)
#        
#        return s3
#s1=student(20,40)
#s2=student(10,10)
#s3=s1+s2
#print(s3.m1)
#print(s3.m2)        
        
'''METHOD OVERLOADING :- python does not support method overloading directly  it can indirectly implement as '''
#
#class mthdoverloading:
##    def __init__(self,m1,m2):
##        self.m1=m1
##        self.m2=m2
##        
#    def sum(self,a=None,b=None,c=None):
#        s=0
#        if a!=None and b!=None and c!=None:
#            s=a+b+c
#        elif a!=None and b!=None:
#            s=a+b
#        else:
#            s=a
#        return s
#
#s1=mthdoverloading() 
#
#print(s1.sum(7,8,6))   
            

'''METHOD OVERIDDING'''
#
#class A:
#    def show(self):
#        print('This is A show')
#
#class B:
#    def show(self):
#        print('This is B show')

#obj=B()
#obj.show()        #call child class method


# 
#class Car:
#    def carprop(self):
#        print('speed','color','gear')
#        
#obj=Car()
#Car.carprop(obj)  



'''REAL LIFE EXAMPLE OF METHOD OVERRIDING'''
#
#class Bank:
#    def getroi(self):
#        return 10
#class SBI(Bank):
#    def getroi(self):
#        return 12
#class IDBI(Bank):
#    def getroi(self):
#        return 9
#class Axis(Bank):
#    def getroi(self):
#        return 11 
#o1=Bank()
#o2=SBI()
#o3=IDBI()
#o4=Axis()   
#
#print('Bank Rate of Interest in %: ',o1.getroi()) 
#print('SBI Rate of Interest in %: ',o2.getroi()) 
#print('IDBI Rate of Interest in %: ',o3.getroi()) 
#print('Axis Rate of Interest in %: ',o4.getroi()) 

'''Creating the constructor in python'''
#class Employee:
#    def __init__(self,id,name,phone):
#        self.id=id
#        self.name=name
#        self.phone=phone
#    def display(self):
#        print('ID:%d \n NAME:%s \n PHONE:%d'%(self.id,self.name,self.phone))
#emp1=Employee(11,'Subhan',7701839980) 
#emp2=Employee(12,'Mehwish',7777777777)
#emp1.display()
#emp2.display()       
#    

'''Python Non-Parameterized Constructor Example'''

#class Student:
#    def __init__(self):
#        print('This is a parametrized constructor')
#    def display(self,name):
#        print('Hello',name)
#student=Student()
#student.display('Subhan khan')
#       

#class Student:
#    def __init__(self):
#        print('This is a parametrized constructor')
#    def display(self,name,roll,addr):
#        self.name=name
#        self.roll=roll
#        self.addr=addr
#        print(self.name,self.roll,self.addr)
#student=Student()
#student.display('Subhan khan'' ',111,' ''asdfgh')

'''Python In-built class functions
The in-built functions defined in the class are described in the following table.

SN	Function	Description
1	getattr(obj,name,default)	It is used to access the attribute of the object.
2	setattr(obj, name,value)	It is used to set a particular value to the specific attribute of an object.
3	delattr(obj, name)	It is used to delete a specific attribute.
4	hasattr(obj, name)	It returns true if the object contains some specific attribute.'''


#class E:
#    def __init__(self,id,name,age):
#        self.name=name
#        self.age=age
#        self.id=id
#obj=E(111,'Subhan',24)
#print(getattr(obj,'name','age'))
#setattr(obj,'age',25)
#setattr(obj,"id",777)  
#print(getattr(obj,'age',"  "'id'))
#print(hasattr(obj,'name'))
#delattr(obj,'name')
#print(hasattr(obj,'name'))
#     

#        
#def fun(x,y):
#    
#    a=x-y
#    b=x+y
#    c=x*y
#    d=x/y
#    return a,b,c,d
#x=int(input('enter x val:'))
#y=int(input('enter y val:'))
#
#result=fun(x,y)
#for i in result:
#     print(i)
#

#class A:
#    def book1(self):
#        print('BOOK1')
#class B(A):
#    def book2(self):
#        print('BOOK2') 
#class C(B):
#    def book3(self):
#        print('BOOK3')
#obj=C()
#obj.book1()
#obj.book2()
#obj.book3()        
#        
        


'''THREAD IN PYTHON'''
#from time import sleep
#from threading import Thread
#class Hello(Thread):
#    def run(self):
#        for i in range(5):
#            print('Hello')
#            sleep(1)
#            
#class Hi(Thread):
#    def run(self):
#        for i in range(5):
#            print('Hi')
#            sleep(1)
#
#t1=Hello()
#t2=Hi()
#t1.start()
#sleep(0.2)
#t2.start()
#            
#t1.join()
#t2.join()
#print('Bye')
##############################################
 
#class Student:
#    
#    name='Subhan'
#    age=22;
#    degree='b.tech'
#    def studentdata(self):
#         print("Name: %s \nAge: %d \nDegree: %s"%(self.name,self.age,self.degree))  
#obj=Student()
#obj.studentdata() 



       
#class Employee:  
#    id = 10;  
#    name = "John"  
#    def display (self):  
#        print("ID: %d \nName: %s"%(self.id,self.name))  
#emp = Employee()  
#emp.display()  

'''USING OOPS CONCEPT CONSTRUCTOR OBJECT '''

#class Car:  
#    def __init__(self,brand,color,gear,speed,price):  
#        self.brand = brand;  
#        self.color = color;
#        self.gear = gear;
#        self.speed = speed;
#        self.price = price;
#    def disp(self):  
#        print("Brand: %s \nColor: %s \nGear %s \nSpeed: %d \nPrice: %d"%(self.brand,self.color,self.gear,self.speed,self.price))  
#c1= Car("BMW","Silver","6",150,1500000) 
# 
#c2 = Car("Mahindra","Blach","5",130,500000)   
#   
#c1.disp();   
#   
#c2.disp();
  

'''AREA OF CIRCLE using constructor,function  '''
#
#class Circle:
#    pi=3.14
#    def __init__(self, radious=0):
#        self.radious=radious
#    def area(self):
#        return self.radious*self.radious*Circle.pi
#    def setRadious(self,radious):
#        self.radious=radious
#    def getRadious(self):
#        return self.radious
#    def parameter(self):
#        return 2*Circle.pi*self.radious
#c = Circle()
#a=int(input('enter how many radious u hv: '))
#for i in range(a):
#    r=int(input('enter rdious>>>>'))
#    c.setRadious(r)
#print('Radious:',c.getRadious())
#print('Area:>',c.area())
#print('Parimeter:>',c.parameter())       

    
 

#class Square():
#    'square class for area and parimeter'
#    
#    def __init__(self, a=0):
#        self.a=a
#    def s_area(self):
#        return self.a**2
#    def s_parimeter(self):
#        return self.a*4
#    def s_set(self,a):
#        self.a=a
#    def s_get(self):
#        return self.a
#x = Square()
#a=int(input('enter no of time u want......: '))
#for i in range(a):
#    b=int(input('enter side of sqr>>>>'))
#    x.s_set(b)
#print('Area:>>>>',x.s_area())
#
#print('Parimeter:>',x.s_parimeter())       



#class Cube(Circle,Square):
#    'cube class for area and parimeter'
#    
#    def __init__(self):
#        print('here cube is created')
#        Square.__init__(self)
#        Circle.__init__(self)
#        
#        
#        
#    def c_area(self):
#        return self.l**3
#    def c_parimeter(self):
#        return self.l*6
#    def c_set(self,l):
#        self.l=l
#    def c_get(self):
#        return self.l
#    
#ob=Cube()
#ob.setRadious(5)
#ob.area()
#ob.c_set(2)
#ob.c_area()


    
    
    
#obj = Cube()
#a=int(input('enter no of time u want......: '))
#for i in range(a):
#    b=int(input('enter side of  cube>>>>'))
#    obj.c_set(b)
#print('Area:>>>>',obj.c_area())
#
#print('Parimeter:>',obj.c_parimeter())       
#



#class Computer():
#    pass
#    
#c = Computer()
#
#print(id(c))   



 