from random import randint

a=0
b=0
c=0
x=["Rock","Paper","Scissor"]
comp=x[randint(0,2)]
player=False
while player==False:
    player=input("Rock,Paper,Scissor:- ")
    if player==comp:
        print("Draw")
        
    elif player=="Rock":
        if comp=="Paper":
            print("you lose!!!",comp,"covers",player)
        else:
            print("you won!!!",player)
        a+=1    
            
    elif player == "Paper":
        if comp == "Scissors":
            print("you loss!! ",comp,"cut",player)
           
        else:
            print("You won!", player, "covers", comp)
        b+=1    
    elif player == "Scissors":
        if comp == "Rock":
            print("You lose...", comp)
        else:
            print("You won!", player, "cut", comp)
        c+=1    
    else:
        print("That's not a valid play. Check your spelling!")
    #player was set to True, but we want it to be False so the loop continues
    player = False
    comp = x[randint(0,2)]
            
    

    
