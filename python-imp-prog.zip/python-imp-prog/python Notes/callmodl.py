'''calling module   wk4'''

import modl4
#print(dir(modl4))
#print(modl4.div(8,4))
#print(modl4.sub(2,4))
#print(modl4.fib(2,4,5))
#print(modl4.mult(4,5))
print(modl4.reverse(1))
#print(modl4.add(4,6))


'''OR'''
#import modl4 as m
#print(m.add(2,8))
#print(m.fib(2,4,6))


'''OR'''
#from modl4 import add,mul 
#print(add(2,8))
#print(mul(4,6))

'''OR'''
#error shows  ....
#from modl4 import *
#print(add(2,8))
#print(mul(4,6))


