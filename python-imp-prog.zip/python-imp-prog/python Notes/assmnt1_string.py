'''1. Python Program to Replace all Occurrences of ‘a’ with $ in a String'''

#str=input('enter string: ')
#str=str.replace('a','$')
#str=str.replace('A','$')
#print('Modified string :')
#print(str)


str='subhan'
str=str.replace('subhan','Mehwish')
print(str)

'''5. Python Program to Count the Number of Vowels  and Consonants in a String'''

#str=input("Enter string:")
#vowels=0
#consonants=0
#for i in str:
#    if(i=='a' or i=='e' or i=='i' or i=='o' or i=='u' or i=='A' or i=='E' or i=='I' or i=='O' or i=='U'):
#        vowels+=1
#    else:
#        consonants+=1            
#            
#print("Number of vowels are: ")
#print(vowels)
#print('No of consonant :',consonansuuuts)

 
'''6. Python Program to Take in a String and Replace Every Blank Space with Hyphen'''

#str=input('enter string: ')
#str=str.replace('','-')
#print('Modified string:',str)  
#print(str) 

'''7. Python Program to Calculate the Length of a String Without Using a Library Function'''

#str=input('enter string :')
#count=0
#for i in str:
#    count+=1
#print('Length of string : ',count)

'''BY USING LIBRARY Fn'''
#print('length of string: ',len(str))

'''11. Python Program to Count Number of Lowercase and upper case Characters in a String'''

#str=input('enter string: ')
#count1=0
#count2=0
#for i in str:
#    if(i.islower()):
#        count1+=1
#    elif(i.isupper()):
#        count2+=1
#print('No. of Lower case: ',count1)
#print('No. of upper case: ',count2)    



'''12. Python Program to Check if a String is a Palindrome or Not'''
'''(A palindrome is a string which is same read forward or backwards.)'''

#str='abcdcba'

#str=input('enter string to check palindrom: ')
#if str==str[::-1]:
#    print('The string is Palindrom')
#else:
#    print('The string is not Palindrom')    


'''15. Python Program to Accept a Hyphen Separated Sequence of Words as Input and 
Print the Words in a Hyphen-Separated Sequence after Sorting them Alphabetically'''


#print("Enter a hyphen separated sequence of words:")
#lst=[n for n in input().split('-')]  
#lst.sort()
#print("Sorted:")
#print('-'.join(lst))

'''16. Python Program to Calculate the Number of Digits and Letters in a String'''

#str=input('enter string: ')
#count1=0
#count2=0
#for i in str:
#    if i.isdigit():
#        count1+=1
#    count2+=1
#print('Number of digits in given string is: ',count1)
#print('Number of Letters in given strig is: ',count2)    
#    

'''17. Python Program to Form a New String Made of the First 2 and Last
 2 characters From a Given String'''
 
#string=input("Enter string:")
#count=0
#for i in string:
#      count=count+1
#new=string[0:2]+string[count-2:count]
#print("Newly formed string is:")
#print(new)
#  
#************OR

#string=input("Enter string:")
#
#for i in string:      
#    new=string[0:2]+string[-2:]      
#print("Newly formed string is:")
#print(new)
#      
   
'''19. Python Program to Check if a Substring is Present in a Given String'''

#string=input("Enter string:")
#sub_str=input("Enter word:")
#if(string.find(sub_str)==-1):
#      print("Substring not found in string!")
#else:
#      print("Substring in string!") 