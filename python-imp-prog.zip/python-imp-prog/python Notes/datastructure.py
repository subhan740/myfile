'''(1.) INSERTION SORT:- build the final list one item at a time
1. consider the 1st element to be sorted & rest unsorted, 2. take the 1st element in the unsorted part u1
and compare it with the sorted element s1...3. if u1<s1 then insert u1 in the correct index else leave as it is

4. take next element in the unsorted part and compare with the sorted elements 5. repet 3 & 4 until all elemnt sorted'''

def InsertionSort(list):
    for index in range(1,len(list)):
        current_element=list[index]
        pos=index
        while current_element < list[pos-1] and pos>0:
            list[pos]=list[pos-1]
            pos=pos-1
        list[pos]=current_element
        
list=[4,2,5,1,6,3,9]
InsertionSort(list)
print(list)        

'''SELECTION SORT ALGO:- compare the element & place    mean value method
1. search the list and find out the number  2.swap the smallest no to 0th index
algo: 1.starting from the 1st element,search for the smallest(biggest)in the list nos
2.swap minimum max no with the 1st element   3. take the sublist and (ignore sorted part) & repet step 1 & 2 
untill all the elements are sorted. 
'''
#list=[4,5,2,2,1,9,0,0]
#print('unsorted list',list)
#for i in range(len(list)):
#    
##    min_val=min(list[i:])
#    min_val=max(list[i:])
#    min_ind=list.index(min_val,i)
#    list[i],list[min_ind]=list[min_ind],list[i]
#print('sorted list',list)

########################OR by function  insert value from user ########################################
#def SelecSort(list):
#    for i in range(len(list)-1):
#        min_val=i
#        for j in range(i,len(list)):
#            if list[j]<list[min_val]:
#                min_val=j
#        list[i],list[min_val]=list[min_val],list[i]
#
#num=int(input('enter how many no. u want to insert:'))        
#list=[int(input('enter random element: ')) for x in range (num)]
#print('unsorted list:',list)
#SelecSort(list)
#print('sorted list',list) 

'''BUBBLE SORT   ALOGORITHM:-
1.starting with the 1st element(index=0) compare the current element with the next element of the list
2.if the current element is greater than the next element then swap them
3. if the current element is less than the next element, move to the next element, repet step1'''
 
#list=[1,0,9,5,7,3,0]
#print('Unsorted list:',list)
#for i in range(len(list)-1,0,-1):
#    for j in range(i):
#        if list[j]>list[j+1]:
#            list[j],list[j+1]=list[j+1],list[j]
#print('sorted list:',list)            


'''BINARY SEARCH
1. Find out the middle element in the sorted list   2. compare "key" with the middle element
3. if "key" is matches with the middle element print Message "key is found"  STOP
4.else if 'key'is greater than the middle element then 'key 'is searched in right sublist start with step1.
5.else if 'key'is smaller than the middle element then 'key 'is searched in left sublist start with step1
6.else print 'key' is not found
'''

#pos=-1
#def BinarySearch(list,key):
#    low=0
#    high=len(list)-1
#    Found=False
#    while low<=high and not Found:
#        mid=(low+high)//2
#        globals()['pos']=mid
#        if key==list[mid]:
#            Found=True
#        elif key>list[mid]:
#            low=mid+1
#        else:
#            high=mid-1
#            
#    if Found==True:
#        print('key is found at index:',pos)
#    else:
#        print('key is not found')
#
#list=[3,0,9,1,5,7,2]
#
#list.sort()
#print('original list:',list)
#key=int(input('enter key value to search:')) 
#BinarySearch(list,key)      
    

'''LINEAR SEARCH/SEQUENCIAL SEARCH
1. start from the leftmost element of list and one by one compare 'key' with each element of list
2. if "key" matched with element then return True   3. else return False
'''    
#pos=-1
#def LinearSearch(list,key):
#    for i in range(len(list)):
#        if key==list[i]:
#            globals()['pos']=i
#            print('key is found at index:',pos)
#            break
#    else:
#        print('key is not found')
#            
#list=[8,0,9,7,3,9,0,1,4]
#print(list)  
#key=int(input('enter key value from the list to search:'))  
#LinearSearch(list,key)        

############################################################################################            
    
     


      