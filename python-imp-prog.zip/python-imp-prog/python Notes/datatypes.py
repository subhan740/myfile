#a="hello world"
#print(a)
#

#print(9 is 9)
#print(10 is not 99)
#print(bin(20))
#
#


#a=7
#b=25
#print(a,bin(a))
##print(b,bin(b))
#print(a&b,bin(a&b))
#print(a|b,bin(a|b))
##


#a='hello'
#print(a,type(a))
#print(a[1:3])
#print(a[2])
#print(a[::])

##
#
#a='UNIVERSE12345'
#print(a)
#print(a[3])
#print(a[-5])
#print(a[1:6:2])
#print(a[::])
#print(a[3:-2])
#print(a[::-1])

#
a='Subhan khan'
#print(a[0:11][::-1])
#print(a[::-1])

#a='UNIVERSE12345'

b='!!!!!!!!!!!aaaaaaaaa!!!!!!!!!!PYTHON$$$$$$$$$$$$$$$$$$$$$$$$$'
#print(a.swapcase())
#print(a.partition('1'))
#print(a.join('subhan'))
#print(b.rstrip('$'))
#print(a.replace('khan','Mehwish'))
#print(a.maketrans({'s':1}))


#print(a+b)
#print(b[::-1])
#print(a[-7:-2:])
#print(a[-7:-2:2])
#print(len(a))
#print(a.capitalize())
#print(a.count('k'))
#print(a.lower())
#print(a.upper())
#print(a.find('n'))
#print(a.index('h'))
#print(a.islower())
#print(a.isupper())
#print(a.isalpha())
#print(a.isnumeric())
#print(a.isdigit())


#
#a=25
#b=50
#c=a+b
##print(c)
#print('the sum of %d & %d is %d'%(a,b,c)
#print('the sum of {} & {} is {}'.format(a,b,c))


#....................STRING EXAMPLE 

#a='S'
#b='abcdef'
#print(a.join(b))
#print(b.replace(a,b))



#a='I AM A PYTHON CODER'
#a='         HELLO            '
#print(a.split())
#print(a.lstrip())
#print(a.rstrip())


#
#a=2.5
#a='hello'
#b='world'
#a=a+b
#print(a)

#print(b*3)
#print(a*3)

#..............LIST EXAMPLE****************************************

#a=['c','c++','python','php','jango']
#print(a)
#print(type(a))
#print(len(a))
#print(a[3])
#print(a[1:4:])
#print(a[::-1])

#b=['lotus','java','java','unix','java']
#c=a+b
#print(c)
#print(b*2)
#b.append('unix')
#b.append(a)
#print(b)
#b.pop(1)
#b.extend(a)
#b.append(a)
#b.sort()

#print(b)



#a=['c','c++','python','php','jango']
#b=[23,4,5,76,24,66,1]
#b.sort()
#print(b)
#b.reverse()
#print(b)
#b.extend(a)
##print(b)
#b.reverse()
#print(b)
#print(b[::-1])
#

#..............TUPLE EXAMPLES self

#t=('java',100,'python',99,'javascript',90)
#t2=('html',25,'css',25)
#print(t)
#print(t[0])
#print(t[1:3:])
#print(t[2:])
#print(t+t2)
#t3=t+t2
#print(t3[::-1])
##


#...........DICTIONARY EXAMPLE  self

#
#dict = {}
#dict['one'] = "This is one"
#dict[2]     = "This is two"
#tdict = {'name':  'john','code':1234,  'dept': 'sales'}
#
#print( dict['one'])
#print(dict[2])
#print(tdict)
#print(tdict.keys())
#print(tdict.values())
#print(tdict.copy())



''' ..................PYTHON BASIC OPERATORS EXAMLE*******************'''

#
#a=20
#b=20
#c=0
#c=a+b
#
#print ("Line 1- value of c is ",c)
#c=a-b
#print ("Line 2- value of c is ",c)
#c=a*b
#print ("Line 3- value of c is ",c)
#c=a/b
#print ("Line 4- value of c is ",c)

#c=a**b
#print ("Line 5- value of c is ",c)

#if(a!=b):
#    print("Line 1 >>> a is equal to b")
#else:
#    print("Line2 >>>  a is not equal to b")
    
#   if(a !=b ):
#    print("Line 2 - a is not equal to b")
#else:
#    print("Line 2 - a is  equal to b")

#if(a<b):
#    print("Line 1 - a is less than b")
#else:
#    print("Line  - a is not less rhan b")
#
#if(a<=b):
#    print("Line 1 - a is less than or equal to b")
#else:
#    print("Line  - a is neither less than nor equal to b")
#    
#...................PYTHON NUMBERS
#    
#print ("abs(-30) : ", abs(-30))
#
#import math
#print ("asin(0.64) :", math.asin(0.64))


#Question:
#Write a program which will find all such numbers which are divisible by 7 but are not a multiple of 5,
#between 2000 and 3200 (both included).
#The numbers obtained should be printed in a comma-separated sequence on a single line.


#list=[]
#for i in range(2000, 3200):
#    if (i%7==0) and (i%5!=0):
#       list.append(str(i))
#
##print (','.join(list))
#print(list)