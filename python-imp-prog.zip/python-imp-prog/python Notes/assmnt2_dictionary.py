'''5. Python Programming Questions on Dictionary'''
'''================================================================================================='''
'''1. Python Program to Add a Key-Value Pair to the Dictionary'''

key=str(input('enter key to be added: '))
value=int(input('enter value of key to be added: '))
dict={}
dict.update({key:value})
print('updated key value is: ',dict)


'''2. Python Program to Concatenate Two Dictionaries Into One'''