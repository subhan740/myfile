'''self    MULtiple inheritance'''

class Customer():
    def __init__(self,ac=0,name=0,addr=0):
        print('Customer account is created')
        self.ac=ac
        self.name=name
        self.addr=addr
    def setName(self,name):
        self.name=name
    def getName(self):
        return self.name
    def setAcc(self,ac):
        self.ac=ac
    def getAcc(self):
        return self.ac
    def setAddr(self,addr):
        self.addr=addr
    def getAddr(self):
        return self.addr

class Bank():
    
    def __init__(self,p=0,r=0,t=0):
        print('customer simple interest is calculated')
        self.p=p
        self.r=r
        self.t=t
     
    def SI(self):
        return self.p*self.r*self.t/100
    
    def setPrinciple(self,p):
        self.p=p
    def getPrinciple(self):
        return self.p
    def setRate(self,r):
        self.r=r
    def getRate(self):
        return self.r
    def setTime(self,t):
        self.t=t
    def getTime(self):
        return self.t
    
    


    
 
class C(Bank,Customer):
    def __init__(self):
        
        Bank.__init__(self)
        Customer.__init__(self)
        print('Customer balance widrawal and deposited')
    def Widraw(self,w,d):
        self.w=w
        self.d=d
        
    def setWidraw(self,w):
        self.w=w
    def getWidraw(self):
        return self.w
    def setDeposit(self,d):
        self.d=d
    def getDeposit(self):
        return self.d
    
  
    
obj=C()
obj.setName('Subhan Khan')
obj.setAddr('Noida Bhangel sector 82')
obj.setAcc('3321630715366')
print('Name of Ac holder is :',obj.getName())
print('Address of Acc holder is :',obj.getAddr())
print('Account No :',obj.getAcc())


obj.setPrinciple(500000)
obj.setRate(10)
obj.setTime(2)
print('P,R,T :',obj.getPrinciple() , obj.getRate() ,obj.getTime())
print('SI is :',obj.SI())


n=int(input('enter amm to widraw:'))
obj.setWidraw(n)
print('widrawal:',obj.getWidraw())
m=int(input('enter ammount to deposit:'))
obj.setDeposit(m)
print('Deposited: ',obj.getDeposit())    
    
    
    
        
        
        
        



 
       
    
 
        
     
        
        
