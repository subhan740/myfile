'''1. Pattern for right angle triangle'''

'''https://www.youtube.com/watch?v=k_B-5Aad7EU&list=PLzgPDYo_3xuliFyI5dZKgYB99SMUscGyp&index=3'''

#n=int(input('enter no of rows: '))
#for i in range(1,n+1):
#    for j in range (1,i+1):
#        print('*',end=" ")
#    print()  
 
   
'''2. Python pattern for pyramid /triangle shape'''
#
#n=int(input('enter a no for raws: '))
#for i in range(0,n):
#    for j in range(0,n-i-1):
#        print(end=" ")
#    for j in range(0,i+1):
#        print('*',end=" ")
#    print()    
#            
'''3. Python pattern for pyramid /triangle shape reverse order'''

#n=int(input('enter number of raws: '))
#for i in range(n,0,-1):
#    for j in range(0,n-i):
#        print(end=" ")
#    for j in range(0,i):
#        print('*',end=" ")
#    print()    
#        
'''4 .Python pattern for diamond  shape'''

#def pyramid(raws):
#    
##raws=int(input('enter no of raws: '))
#    for i in range(raws):
#        print(' '*(raws-i-1)+'* '*(i+1))
#    for j in range(raws-1,0,-1):
#        print(' '*(raws-j)+'* '*(j))

#   
'''5. Python pattern for  A  shape'''


#for raw in range(7):
#    for col in range(5):
#        if((col==0 or col==4) and raw!=0) or ((raw==0 or raw==3) and (col>0 and col<4)):
#            print("*",end="")
#        else:
#            print(end=" ")
#    print() 

'''6. Python pattern for B  shape'''

#for raw in range(7):
#    for col in range(5):
#        if(col==0 or col==4) or ((raw==0 or raw==3 or raw==6) and (col>0 and col<4)):
#            print("*",end="")
#        else:
#            print(end=" ")
#    print()       
#       
'''OR   B shape'''
#for raw in range(7):
#    for col in range(5):
#        if(col==0)  or (col==4 and raw!=0 and raw!=3 and raw!=6) or((raw==0 or raw==3 or raw==6) and (col>0 and col<4)):
#            print("*",end="")
#        else:
#            print(end=" ")
#    print()       
#       
'''7. Python pattern for C  shape'''

#for raw in range(7):
#    for col in range(5):
#        if (col==0) or (raw==0 or raw==6):
#            print('*',end=" ")
#        else:
#            print(end=" ")
#    print()        
#        

'''8. Python pattern for D  shape'''

#
#for raw in range(7):
#    for col in range(5):
#        if (col==0) or (col==4 and raw!=0 and raw!=6) or ((raw==0 or raw==6) and (col>0 and col<4)):
#            print('*',end="")
#        else:
#            print(end=" ")
#    print()        
        

'''9. Python pattern for E  shape'''

#for raw in range(7):
#    for col in range(5):
#        if (col==0) or ((raw==0 or raw==3 or raw==6) and (col>0)):
#            print('*',end="")
#        else:
#            print(end=" ")
#    print()   
#    
'''10. Python pattern for F  shape''' 

#for raw in range(7):
#    for col in range(5):
#        if (col==0) or ((raw==0 or raw==3) and (col>0)):
#            print('*',end=" ")
#        else:
#            print(end=" ")
#    print()   
#       

'''11.  Python pattern for G  shape''' 


#for raw in range(7):
#    for col in range(6):
#        if (col==0) or (col==4 and (raw!=1 and raw!=2)) or ((raw==0 or raw==6) and (col>0 and col<4)) or (raw==3 and (col==3 or col==5)):
#            print('*',end="")
#        else:
#            print(end=" ")
#    print()   
#       

'''12. Python pattern for H  shape''' 

#
#for raw in range(7):
#    for col in range(5):
#        if (col==0 or col==4) or (raw==3 and (col>0 and col<4)):
#            print('*',end="")
#        else:
#            print(end=" ")
#    print()   
#       

'''13. Python pattern for I  shape''' 


#for raw in range(7):
#    for col in range(5):
#        if (col==3) or (raw ==0 or raw==6) and(col==2 or col==4):
#             print('*',end="")
#        else:
#            print(end=" ")
#    print()   
#       

'''14. Python pattern for J  shape''' 

#
#for raw in range(7):
#    for col in range(5):
#        if (col==3) or (raw ==0) and(col==2 or col==4) or (raw==6 and (col!=4)) or (col==0 and (raw==5 or raw==4)):
#             print('*',end="")
#        else:
#            print(end=" ")
#    print()   
#    
'''15. Python pattern for K  shape''' 


#for raw in range(7):
#    for col in range(5):
#        if (col==0) or (raw ==3 and (col==1)) or ((raw==2 or raw==4) and (col==2)) or ((raw==1 or raw==5) and (col==3)) or ((raw==0 or raw==6) and (col==4)):
#             print('*',end="")
#        else:
#            print(end=" ")
#    print()   
    
'''16. Python pattern for L  shape''' 


#for raw in range(7):
#    for col in range(5):
#        if (col==0) or (raw ==6) or (col==4 and(raw==5)):
#             print('*',end="")
#        else:
#            print(end=" ")
#    print()   
#    

'''17. Python pattern for M  shape''' 

#
#for raw in range(7):
#    for col in range(7):
#        if (col==0 or col==6)or(raw==1 and(col==1))or(raw==2 and(col==2))or(raw==3 and(col==3))or(raw==1 and(col==5))or(raw==2 and(col==4)):
#             print('*',end="")
#        else:
#            print(end=" ")
#    print()   
#    
    
#
#for raw in range(7):
#    for col in range(7):
#        if (col==0 or col==6)or(raw==col and (col>0 and col<4 ))or(raw==1 and(col==5))or(raw==2 and(col==4)):
#             print('*',end="")
#        else:
#            print(end=" ")
#    print()       
#
'''18. Python pattern for N shape'''  
#
#    
#
#for raw in range(7):
#    for col in range(7):
#        if (col==0 or col==6)or(raw==col and (col>0 and col<6 )):
#             print('*',end="")
#        else:
#            print(end=" ")
#    print() 
# 
#
'''19. Python pattern for O shape'''  
#
#    
#
#for raw in range(7):
#    for col in range(5):
#        if ((col==0 or col==4) and (raw!=0 and raw!=6)) or ((raw==0 or raw==6) and (col>0 and col<4)):
#             print('*',end="")
#        else:
#            print(end=" ")
#    print() 
#     

#
'''20. Python pattern for P shape'''  
#
#    
#
#for raw in range(7):
#    for col in range(5):
#        if (col==0 and raw!=0)or (col==4 and (raw>0 and raw<3)) or ((raw==0 or raw==3) and (col>0 and col<4)):
#             print('*',end="")
#        else:
#            print(end=" ")
#    print() 
#
'''21. Python pattern for Q shape'''  
#
#    
#
#for raw in range(7):
#    for col in range(5):
#        if ((col==0 or col==4) and (raw>0 and raw<5)) or ((raw==0 or raw==5) and (col>0 and col<4))or(raw==4 and col==1) or (raw==6 and col==3):
#             print('*',end="")
#        else:
#            print(end=" ")
#    print() 
# 
'''22.  Python pattern for R shape'''  
#
#    
#
#for raw in range(7):
#    for col in range(5):
#        if (col==0 and raw!=0)or (col==4 and (raw>0 and raw<3)) or ((raw==0 or raw==3) and (col>0 and col<4))or(raw==4 and col==2)or(raw==5 and col==3)or(raw==6 and col==4):
#             print('*',end="")
#        else:
#            print(end=" ")
#    print() 
#         
'''23. Python pattern for S shape'''  
#
#    
#
#for raw in range(7):
#    for col in range(5):
#        if(raw==0 or raw==3 or raw==6)or (col==0 and(raw>0 and raw<3))or(col==4 and (raw>3 and raw<6))or(raw==5 and col==0)or(raw==1 and col==4) :
#             print('*',end="")
#        else:
#            print(end=" ")
#    print() 

'''24. Python pattern for T shape'''  

    
#
#for raw in range(5):
#    for col in range(5):
#        if(raw==0)or (col==2 and raw>0) :
#             print('*',end="")
#        else:
#            print(end=" ")
#    print()

'''25. Python pattern for U shape'''  
#
#    
#
#for raw in range(7):
#    for col in range(5):
#        if ((col==0 or col==4) and (raw!=0 and raw!=6)) or (raw==6 and (col>0 and col<4)):
#             print('*',end="")
#        else:
#            print(end=" ")
#    print() 
# 

'''26. Python pattern for V shape'''  

    
#
#for raw in range(5):
#    for col in range(9):
#        if(raw==col)or(raw==3 and col==5)or(raw==2 and col==6)or(raw==1 and col==7)or(raw==0 and col==8):
#             print('*',end="")
#        else:
#            print(end=" ")
#    print()
    
'''OR'''
i=0
j=8    
for raw in range(5):
    for col in range(9):
        if(raw==col):
             print('*',end="")
        elif raw==i and col==j:
            print('*',end="")
            i+=1
            j-=1
            
        else:
            print(end=" ")
    print()     
   
# 
'''27. Python pattern for V shape'''  
#i=0
#j=3
#for raw in range(4):
#    for col in range(7):
#        if(col==0 or col==6)or (raw==2 and col==5)or(raw==1 and col==4):
#             print('*',end="")
#        elif raw==i and col==j:
#            print('*',end="")
#            i+=1
#            j-=1     
#        else:
#            print(end=" ")
#    print()   

 
'''28. Python pattern for W shape'''  
#i=0
#j=3
#for raw in range(4):
#    for col in range(7):
#        if(col==0 or col==6)or (raw==2 and col==5)or(raw==1 and col==4):
#             print('*',end="")
#        elif raw==i and col==j:
#            print('*',end="")
#            i+=1
#            j-=1     
#        else:
#            print(end=" ")
#    print()
#                    
'''29. Python pattern for X shape'''  
#i=0
#j=4
#for raw in range(5):
#    for col in range(5):
#        if raw==i and col==j:
#             print('*',end="")
#             i+=1
#             j-=1  
#        elif raw==col:
#            print('*',end="")
#               
#        else:
#            print(end=" ")
#    print()

'''30. Python pattern for Y shape'''  
#i=0
#j=4
#for raw in range(5):
#    for col in range(6):
#        if (raw==col and raw<2)or(col==3 and raw>1)or(raw==0 and col==5)or(raw==1 and col==4):
#             print('*',end="")
#        else:
#            print(end=" ")
#    print()


'''31. Python pattern for Z shape''' 

#i=1
#j=4
#for raw in range(6):
#    for col in range(6):
#        if(raw==0 or raw==5):
#            print('*',end="")
#        elif raw==i and col==j:
#            print('*',end="")
#            i=i+1
#            j=j-1
#        else:
#            print(end=" ")
#    print()       
        
'''IMP pattern
A
C D
G H I
M N O P
U V W X Y
'''

#A=65
#C=67
#G=71
#M=77
#U=85
#for raw in range(5):
#    for col in range(5):
#        if raw==0 and col<1:
#            print(chr(A),end=" ")
#        
#        elif raw==1 and col<2:            
#            print(chr(C),end=" ")
#            C+=1
#        elif raw==2 and col<3:
#            print(chr(G),end=" ")
#            G+=1    
#        elif raw==3 and col<4:
#            print(chr(M),end=" ")
#            M+=1
#        elif raw==4:
#            print(chr(U),end=" ")
#            U+=1
#    print() 
#    
# 
#   
#A=91
#C=92
#G=93
#M=94
#U=95
#for raw in range(5):
#    for col in range(5):
#        if raw==0 and col<1:
#            print(chr(A),end=" ")
#        
#        elif raw==1 and col<2:            
#            print(chr(C),end=" ")
#            C+=1
#        elif raw==2 and col<3:
#            print(chr(G),end=" ")
#            G+=1    
#        elif raw==3 and col<4:
#            print(chr(M),end=" ")
#            M+=1
#        elif raw==4:
#            print(chr(U),end=" ")
#            U+=1
#    print()     
# 
'''PRINTING ASCII CHARACTER VALUE '''       
#
#a=65
#for i in range(65,122):
#    print(a,chr(a))
#    a=a+1

''' FABONACCI SERIES'''
#a,b=0,1
#for i in range(0, 10):
#    print(a)
#    a,b=b,a+b
#    


