#PYTHON PROGRAM TO PRINYT AREA OF TRIANGLE
#a=float(input('enter value of side a:'))
#b=float(input('enter value of side b:'))
#c=float(input('enter value of side c'))
#s=(a+b+c)/2
#area=(s*(s-a)*(s-b)*(s-c))**0.5
#print(area)


#PYTHON PROGRAM TO DISPLAY CALENDER

#import calendar
#yy=int(input('enter year:'))
#mm=int(input('enter month:'))
#print(calendar.month(yy,mm))


###Python Program to Add Two Matrices
#X = [[1,2,3],  
#      [4,5,6],  
#      [7,8,9]]  
#  
#Y = [[10,11,12],  
#      [13,14,15],  
#      [16,17,18]]  
#  
#Result = [[0,0,0],  
#          [0,0,0],  
#          [0,0,0]]  
## iterate through rows  
#for i in range(len(X)):  
#   # iterate through columns  
#   for j in range(len(Y)):  
#       Result[i][j]+= X[i][j] + Y[i][j]  
#
#for r in Result:  
#   print(r)  

#X = [[1,2,3],  
#       [4,5,6],  
#       [7,8,9]]  
#  
#Y = [[10,11,12],  
#      [13,14,15],  
#      [16,17,18]]  
#  
#result = [[0,0,0],  
#               [0,0,0],  
#              [0,0,0]]  
#  
## iterate through rows of X  
#for i in range(len(X)):  
#   for j in range(len(Y[0])):  
#       for k in range(len(Y)):  
#           result[i][j] += X[i][k] * Y[k][j]  
#for r in result:  
#   print(r)  



'''Python Program to Sort Words in Alphabetic Order'''

#words=input('enter list of words')
#w=words.split()
#print(w)
#w.sort()
#
##print(w)
#
#for word in w:
#    print(word)


'''Python Program to Remove Punctuation from a String'''

#s=input('enter strings:')
#for punc in s:
#    if punc not in '!@#$%^&*:";?{}[]()+=-_)(<,>.':
#        print(punc)

#######OORRRRRR**************************************
# define punctuation  

#punctuation = '''''!()-[]{};:'"\,<>./?@#$%^&*_~'''  
## take input from the user  
#my_str = input("Enter a string: ")  
## remove punctuation from the string  
#no_punct = ""  
#for char in my_str:  
#   if char not in punctuation:  
#       no_punct = no_punct + char  
## display the unpunctuated string  
#print(no_punct)  


'''Python Program to Check Leap Year'''

#yyyy=int(input('enter year:'))
#if(yyyy%4==0):
#    if (yyyy%100==0):
#        if(yyyy%400==0):
#            print('{0} is a leap year'.format(yyyy))
#        else:
#            print('{0} is not a leap year:')
#    else:
#        print('{0} is a leap year'.format(yyyy))
#else:
#    print('{0} is not a leap year'.format(yyyy))        
#        

'''
Python Program to Check Prime Number'''

#n=int(input('enter a no:'))
#n>1
#for i in range(2,n):
#    if (n%i==0):
#        print('Not Prime:')
#        break
#else:
#    print('prime no:')

#
#a=int(input('enter lower range:'))
#b=int(input('enter upper range:'))
#
#for n in range(a,b+1):
#    if n>0:
#        for i in range(2,n):
#            if (n%i==0):
#            
#                break
#        else:
#            print('prime no:',n)

'''Python Program to Find the Factorial of a Number'''
#n=int(input('enter a no:'))
#n>0
#fact=1
#if n==0:
#    print('fact of 0 is 1')
#if n<0:
#    print('factorial does not exist of negative no') 
#else:
#    for i in range(1,n+1):
#        fact=fact*i    
#print('fact is',(fact))    


######MULTIPLICATION TABLE

#n=int(input('enter a no:'))
#for i in range(1,11):
#    print(n,'X',i,"=",n*i)

'''
Python Program to Print the Fibonacci sequence'''

#n=int(input('enter a no:'))
#a,b=0,1
#for i in range(n):
#    print(a)
#    a,b=b,a+b
#   

'''Python Program to Check Armstrong Number
A number is called Armstrong number if it is equal to the sum of the cubes of its own digits.

For example: 153 is an Armstrong number since 153 = 1*1*1 + 5*5*5 + 3*3*3.'''

#n=int(input('enter a no:'))
#digit=0
#temp=n
#sum=0
#while temp>0:
#    digit=temp%10
#    sum=sum+digit**3
#    temp//=10
#if(n==sum):
#    
#    print('arm angstrom no:',sum)
#else:
#    print('good bye')    

'''Python Program to Find LCM'''
#def lcm(x,y):
#    if x>y:
#        greater=x
#    else:
#        greater=y
#    while(True):    
#        if((greater%x==0) and (greater%y==0)):    
#            lcm=greater
#            break
#        greater+=1
#    return lcm
#print('hello')    
#n1=int(input('enter 1st no:')) 
#n2=int(input('enter 2nd no:'))   
#print("LCM of",n1,"and",n2,":-",lcm(n1,n2))

'''Python Program to Find HCF'''
#def hcf(x,y):
#    l=int(input('enter 1st no:'))
#    u=int(input('enter 2nd no:'))
#    for i in range(1,l+1):
#        if((l%i==0)and(u%i==0)):
#            hcf=i
#    return hcf
#print(hcf(1,2)) 
'''Python Program To Find ASCII value of a character'''
#
#c=input('enter a character:')
#print("The ASCII value of '" + c + "' is",ord(c)) 


'''Python Program to Make a Simple Calculator'''

#def add(x,y):
#    return x+y
#def sub(x,y):
#    return x-y
#def mult(x,y):
#    return x*y
#def div(x,y):
#    return x/y    
#
#print('select choice:')
#
#print('1.add')
#print('2.sub')
#print('3.mult')
#print('4.div')
#
#choice=input('enter choice(1/2/3/4):')
#
#n1=int(input('enter 1st num:'))
#n2=int(input('enter 2nd num:'))
#
#
#if choice=='1':
#    print("ADDITION of",n1,'and',n2,'is:',add(n1,n2))
#  
#elif choice=='2':
#    print("SUBTRACTION of",n1,'and',n2,'is:',sub(n1,n2))
#
#elif choice=='3':
#    print("MULTIPLICATION of",n1,'and',n2,'is:',mult(n1,n2))
#    
#elif choice=='4':
#    print("DIVISION of",n1,'and',n2,'is:',div(n1,n2))  
#    
#else:
#    print('Invalid input')    


'''IMP>>>Python Program to Display Fibonacci Sequence Using Recursion'''
#
#def recur_fib(n):
#    if n<=1:
#        return n
#    else:
#        return(recur_fib(n-1)+recur_fib(n-2))
#a=int(input('enter no for fibonacci:'))
#if a<=0:
#    print('enter positive integer')
#else:
#    print('FIBONACCI series:')    
#    for i in range(a):
#    
#        print(recur_fib(i))
#        
      
'''IMP>>>Python Program to Find Factorial of Number Using Recursion'''

#def recur_factorial(n):
#    if n==1:
#        return n
#    else:
#        return(n*recur_factorial(n-1))  
#num=int(input('enter a no:'))
#if num<0:
#    print('sorry fact of -ve does not exist:')
#elif num==0:
#    print('factorial of 0 is:1')
#else:
#    print('factorial of',num,'is:',recur_factorial(num))        
#  

'''PYTHON ARRAY PROGRAMS

Python program to copy all elements of one array into another array'''
#arr1=[1,2,3,4,5]
#arr2=[None]*len(arr1)           #Create another array arr2 with size of arr1 
#for i in range(len(arr1)):
#    arr2[i]=arr1[i]      #copying all elements of one array into another array
#    
#    
#print('Displaying element of array1:')
#for i in range(len(arr1)):
#    print(arr1[i])
#
#print('Displaying element of array2:')
#for i in range(len(arr2)):
#    print(arr2[i])
   
    
'''IMP Python program to print the duplicate elements of an array'''

#arr=[1,2,3,2,4,5,3,6]
#print('Duplicate elements are:')
#for i in range(len(arr)):
#    for j in range(i+1,len(arr)):
#        if arr[i]==arr[j]:
#            
#            print(arr[j])

''' Python program to print the elements of an array in reverse order'''

#arr=[1,22,3,4,5,6,7]
#print('printing original array:')
#for i in range(0,len(arr)):
#    print(arr[i])
#    
#print('printing reverse array:')
#for i in range(len(arr)-1,-1,-1):
#    print(arr[i])    
##ORRR
#
#for i in range(0,len(arr)):
#    print(end="")
#print(arr[i::-1])
#
##ORRRRRRRr
#print(arr[::-1])


'''Python program to print the elements of an array present on even position'''
#
#arr=[1,2,3,5,6,7,9,0]
#print('array present at even position:')
#i=0
#while i<len(arr):
#    if i%2==0:
#        print(arr[i])
#    i=i+2
#    
##OORRRR
#    
##Initialize array     
#arr = [1, 2, 3, 4, 5];     
#     
#print("Elements of given array present on even position: ");    
##Loop through the array by incrementing the value of i by 2    
#    
##Here, i will start from 1 as first even positioned element is present at position 1.    
#for i in range(1, len(arr), 2):    
#    print(arr[i]);       
#    
     
'''Python program to print the largest element in an array'''   
   
#arr=[1,2,9,4,7,6,3]
#print(max(arr))         # using inbuilt function max
#print(min(arr))

########OOORRRR
#
#arr=[9,3,8,7,6,0]
#max_val=arr[0]
#for i in range(1,len(arr)):
#    if arr[i]>max_val:
#        max_val=arr[i]
#print(max_val)        

#######OOOORRR    taking values form user

#arr=[]
#num=int(input('enter no of val:'))
#for i in range (num):
#    e=int(input('enter elements:'))
#    arr.append(e)
#    print(arr)
#arr.sort()
#print(arr)
#print('largest element of given index is:',arr[num-1])  
#print('second largest element in array/list is:',arr[num-2]) 

 
'''Python program to print the number of elements present in an array'''

#arr=[1,4,6,8,9,0,2,3,1,1,1,2,1]
#count=0
#for i in range(len(arr)):
#    count+=1
#print(count)
###OOORRR  using built in function
#print(str(len(arr)))    

'''Python program to print the sum of all elements in an array'''
#arr=[1,2,3,4,5,6,4]
#sum=0
#for i in range(len(arr)):
#    sum+=arr[i]
#print('SUM OF ARRAY ELEMENT:',sum)    

'''Python program to sort the elements of an array in ascending /decending order'''
#arr=[3,5,7,9,10,1,2,3] 
#arr.sort()
#print(arr) 
#print(arr[::-1])  
#
'''Python program to print digit 1 to 100 without loop'''
#def Num(n):
#    if n>0:
#        Num(n - 1)
#        print(n,end=" ")
#Num(100)        
#      


'''REMOVE SPECIAL CHARACTER FROM A GIVEN STRING'''
#import re
#line = 'Q: Do I write ;/.??? No!!!'
#print(re.sub('\ |\?|\.|\!|\/|\;|\:', '', line))

       
'''Insertion sort'''
#def InsertionSort(list1):
#    for index in range(1,len(list1)):
#        current_element=list1[index]
#        pos=index
#        while current_element<list1[pos-1] and pos>0:
#            list1[pos]=list1[pos-1]
#            pos=pos-1
#        list1[pos]=current_element
#        
#list1=[2,5,1,0,9]
#InsertionSort(list1)
#print(list1)        
#        



# function to check string is  
# palindrome or not 



def isPalindrome(s): 
      
    # Using predefined function to  
    # reverse to string print(s) 
    rev = ''.join(reversed(s)) 
  
    # Checking if both string are  
    # equal or not 
    if (s == rev): 
        return True
    return False
  
# main function 
s = "malayalam"
ans = isPalindrome(s) 
  
if (ans): 
    print("Yes") 
else: 
    print("No        