# -*- coding: utf-8 -*-
"""
Created on Wed Jan  2 16:11:18 2019

@author: pythor
"""
'''
GUI
'''

#import tkinter
#top=tkinter.Tk()
#top.mainloop()



#from tkinter import *
#from tkinter import messagebox
#top = Tk()
#top.geometry("200x200")
#def helloCallBack():
#    msg=messagebox.showinfo( "Hello Python", "Hello World")
#B = Button(top, text ="Hello", command = helloCallBack)
#B.place(x=50,y=50)
#top.mainloop()


#from tkinter import *
#from tkinter import messagebox
#top = Tk()
#C = Canvas(top, bg="blue", height=250, width=300)
#coord = 10, 50, 240, 210
#arc = C.create_arc(coord, start=0, extent=150, fill="red")
#line = C.create_line(10,10,200,200,fill='white')
#C.pack()
#top.mainloop()


#from tkinter import *
#import tkinter
#top = Tk()
#CheckVar1 = IntVar()
#CheckVar2 = IntVar()
#C1 = Checkbutton(top, text = "Music", variable = CheckVar1, \
#onvalue = 1, offvalue = 0, height=5, \
#width = 20, )
#C2 = Checkbutton(top, text = "Video", variable = CheckVar2, \
#onvalue = 1, offvalue = 0, height=5, \
#width = 20)
#C1.pack()
#C2.pack()
#top.mainloop()


#from tkinter import *
#top = Tk()
#L1 = Label(top, text="User Name")
#L1.pack( side = LEFT)
#E1 = Entry(top, bd =5)
#E1.pack(side = RIGHT)
#top.mainloop()



#from tkinter import *
#top = Tk()
#top.geometry("300x300")
#L1 = Label(top, text="User Name")
#L2 = Label(top, text="Password")
##L1.pack( side = LEFT)
##L2.pack( side = LEFT)
#E1 = Entry(top, bd =5)
##E1.pack(side = RIGHT)
#E2 = Entry(top, bd =5)
##E2.pack(side = RIGHT)
#L2.place(x=50,y=70)
#L1.place(x=40,y=10)
#E2.place(x=30,y=100)
#E1.place(x=30,y=30)
#top.mainloop()


#from tkinter import *
#root = Tk()
#frame = Frame(root)
#frame.pack()
#bottomframe = Frame(root)
#bottomframe.pack( side = BOTTOM )
#redbutton = Button(frame, text="Red", fg="red")
#redbutton.pack( side = LEFT)
#greenbutton = Button(frame, text="Brown", fg="brown")
#greenbutton.pack( side = LEFT )
#bluebutton = Button(frame, text="Blue", fg="blue")
#bluebutton.pack( side = LEFT )
#blackbutton = Button(bottomframe, text="Black", fg="black")
#blackbutton.pack( side = BOTTOM)
#root.mainloop()


#from tkinter import *
#root = Tk()
#var = StringVar()
#label = Label( root, textvariable=var, relief=RAISED )
#var.set("Hey!? How are you doing?")
#label.pack()
#root.mainloop()



#from tkinter import *
##import tkinter
#top = Tk()
#Lb1 = Listbox(top)
#Lb1.insert(1, "Python")
#Lb1.insert(2, "Perl")
#Lb1.insert(3, "C")
#Lb1.insert(4, "PHP")
#Lb1.insert(5, "JSP")
#Lb1.insert(6, "Ruby")
#Lb1.pack()
#top.mainloop()


#from tkinter import *
#import tkinter
#top = Tk()
#mb= Menubutton ( top, text="condiments", relief=RAISED )
#mb.grid()
#mb.menu = Menu ( mb, tearoff = 0 )
#mb["menu"] = mb.menu
#mayoVar = IntVar()
#ketchVar = IntVar()
#mb.menu.add_checkbutton ( label="mayo",
#variable=mayoVar )
#mb.menu.add_checkbutton ( label="ketchup",
#variable=ketchVar )
#mb.pack()
#top.mainloop()


#from tkinter import *
#def donothing():
#    filewin = Toplevel(root)
#    button = Button(filewin, text="Do nothing button")
#    button.pack()
#root = Tk()
#menubar = Menu(root)
#filemenu = Menu(menubar, tearoff=0)
#filemenu.add_command(label="New", command=donothing)
#filemenu.add_command(label="Open", command=donothing)
#filemenu.add_command(label="Save", command=donothing)
#filemenu.add_command(label="Save as...", command=donothing)
#filemenu.add_command(label="Close", command=donothing)
#filemenu.add_separator()
#filemenu.add_command(label="Exit", command=root.quit)
#menubar.add_cascade(label="File", menu=filemenu)
#editmenu = Menu(menubar, tearoff=0)
#editmenu.add_command(label="Undo", command=donothing)
#editmenu.add_separator()
#editmenu.add_command(label="Cut", command=donothing)
#editmenu.add_command(label="Copy", command=donothing)
#editmenu.add_command(label="Paste", command=donothing)
#editmenu.add_command(label="Delete", command=donothing)
#editmenu.add_command(label="Select All", command=donothing)
#menubar.add_cascade(label="Edit", menu=editmenu)
#helpmenu = Menu(menubar, tearoff=0)
#helpmenu.add_command(label="Help Index", command=donothing)
#helpmenu.add_command(label="About...", command=donothing)
#menubar.add_cascade(label="Help", menu=helpmenu)
#root.config(menu=menubar)
#root.mainloop()



#from tkinter import *
#root = Tk()
#var = StringVar()
#label = Message( root, textvariable=var, relief=RAISED )
#var.set("Hey!? How are you doing?")
#label.pack()
#root.mainloop()


#from tkinter import *
#def sel():
#    selection = "You selected the option " + str(var.get())
#    label.config(text = selection)
#root = Tk()
#var = IntVar()
#R1 = Radiobutton(root, text="Option 1", variable=var, value=1, command=sel)
#R1.pack( anchor = W )
#R2 = Radiobutton(root, text="Option 2", variable=var, value=2, command=sel)
#R2.pack( anchor = W )
#R3 = Radiobutton(root, text="Option 3", variable=var, value=3, command=sel)
#R3.pack( anchor = W)
#label = Label(root)
#label.pack()
#root.mainloop()


# An example of a recursive function to
# find the factorial of a number

#def calc_factorial(x):
#    """This is a recursive function
#    to find the factorial of an integer"""
#
#    if x == 1:
#        return 1
#    else:
#        return (x * calc_factorial(x-1))
#
#num = 5
#print("The factorial of", num, "is", calc_factorial(num))




#for i in [4, 7, 0, 3]:
#    print(i)

#
#my_list = [4, 7, 0, 3]
#
## get an iterator using iter()
#my_iter = iter(my_list)
#
### iterate through it using next() 
#
##prints 4
#print(next(my_iter))
#
##prints 7
#print(next(my_iter))
#
### next(obj) is same as obj.__next__()
#
##prints 0
#print(my_iter.__next__())
#
##prints 3
#print(next(my_iter))
#
### This will raise error, no items left
#next(my_iter)



## A simple generator function
#def my_gen():
#    n = 1
#    print('This is printed first')
#    # Generator function contains yield statements
#    yield n
#
#    n += 1
#    print('This is printed second')
#    yield n
#
#    n += 1
#    print('This is printed at last')
#    yield n
#
## Using for loop
#for item in my_gen():
#    print(item)


##from tkinter import *
##import tkinter
##top = Tk()
##CheckVar1 = IntVar()
##CheckVar2 = IntVar()
##C1 = Checkbutton(top, text = "Music", variable = CheckVar1, \
##onvalue = 1, offvalue = 0, height=5, \
##width = 20, )
##C2 = Checkbutton(top, text = "Video", variable = CheckVar2, \
##onvalue = 1, offvalue = 0, height=5, \
##width = 20)
##C1.pack()
##C2.pack()
##top.mainloop()





























