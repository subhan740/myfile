
'''1. Python Program to Count the Number of Vowels Present in a String using Sets'''

#str=input('enter string: ')
#count=0
#vowels=set('aeiou')
#for i in str:
#    if i in vowels:
#        count+=1
#print('number of the vowel is: ')
#print(count)

OR

s=input("enter string:")
count=0
for i in s:
    if i in 'aeiou':
        count+=1
print(count)        


'''2. Python Program to Check Common Letters in Two Input Strings'''

#s1=input('enter 1st string: ')
#s2=input('enter 2nd string: ')
#for i in s1:
#    if i in s2:
#        print(i)
#        
#    
'''OR'''

#s1=input("Enter first string:")
#s2=input("Enter second string:")
#a=list(set(s1)&set(s2))
#print("The common letters are:")
#for i in a:
#    print(i)
#    

'''3. Python Program that Displays which Letters are in the First String but not in the Second'''

#s1=input("Enter first string:")
#s2=input("Enter second string:")
#a=list(set(s1)-set(s2))
#print("The letters are:")
#for i in a:
#    print(i)

'''4. Python Program that Displays which Letters are Present in Both the Strings'''

#s1=input("Enter first string:")
#s2=input("Enter second string:")
#a=list(set(s1)|set(s2))
#print("The letters are:")
#for i in a:
#    print(i)

'''5. Python Program that Displays which Letters are in the Two Strings but not in Both'''

#s1=input("Enter first string:")
#s2=input("Enter second string:")
#a=list(set(s1)^set(s2))
#print("The letters are:")
#for i in a:
#    print(i)
#


#
#class Computer():
#    
#    pass
#c1 = Computer()
#c2=Computer()
#c3=Computer()
#
#print(id(c1))    
#print(id(c2))
#print(id(c3))