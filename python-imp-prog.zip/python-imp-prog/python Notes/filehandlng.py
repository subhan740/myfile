'''FILE HANDLING '''

#a=open('myfile.txt','w')
#a.write('Hli! my name is subhan ali and i am a b.tech final year student in computer science engg')
#print('file excuted succ.....')
#a.close()

#
#a=open('myfile.txt','r')
#x=a.read()
#print(x)
#a.close()



import os
#os.rename('myfile.txt','newfile.txt')

#os.remove('newfile.txt')
#os.mkdir('pythonworld')
#os.rename('pythonworld','pythondir')
#os.rmdir('pythondir')

