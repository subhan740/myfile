
'''--------INHERITANCE EXAMPLE------------------------------------------'''  

'''AREA OF CIRCLE using constructor,function  '''

class Circle():
    pi=3.14
    def __init__(self, radious=0):
        self.radious=radious
    def area(self):
        return self.radious*self.radious*Circle.pi
    def setRadious(self,radious):
        self.radious=radious
    def getRadious(self):
        return self.radious
    def parameter(self):
        return 2*Circle.pi*self.radious

    
 

class Square():
    'square class for area and parimeter'
    
    def __init__(self, a=0):
        self.a=a
    def s_area(self):
        return self.a**2
    def s_parimeter(self):
        return self.a*4
    def s_set(self,a):
        self.a=a
    def s_get(self):
        return self.a
#


class Cube(Circle,Square):
    'cube class for area and parimeter'
    
    def __init__(self):
        print('here cube is created')
        Square.__init__(self)
        Circle.__init__(self)
        
        
        
    def c_area(self):
        return self.l**3
    def c_parimeter(self):
        return self.l*6
    def c_set(self,l):
        self.l=l
    def c_get(self):
        return self.l
    
ob=Cube()
ob.setRadious(5)
print(ob.getRadious())
print(ob.parameter())
print(ob.area())
ob.c_set(2)
print(ob.c_area())
print('Parimeter of cube is',ob.c_parimeter())
ob.s_set(3)
print('Area of Square is: ',ob.s_area())
print('Parimeter of Square is: ',ob.s_parimeter())


    
    
