'''Python program to calculate average of a number in a given list'''
#list=[]
#a=20
#b=5
#c=10
#c=a+b+c/3
#list.append(c)
#print(list)
##########
#n=int(input('enter no of elements to calculate avg: '))
#list=[]
#for i in range(n):
#    e=int(input('enter elements: '))
#    list.append(e)
#avg=sum(list)/n
#print('The avg of  given element in the list: ',avg)
#  
###########
#list=[1,2,3,4,5]
#avg=sum(list)/5
#print('avg>>>>',avg)  

'''Python Program to exchange value of two no without using temporary variable'''
#a,b=10,20
#a,b=b,a
#print('value of a&b>>>',a,b)



#a,b=b,a=12,23
#print('value of a & b >>>', a,b)

'''Python Program to Read a number n and Compute n+nn+nnn'''
#n=int(input('enter a number: '))
#n1=str(n)
#n2=n1+n1
#n3=n1+n1+n1
#sum=n+int(n2)+int(n3)
#print(sum)
#print(n1,'+',n2,'+',n3 ,"... =", sum)


#a='subhan'
#print(a.upper())
'''Python Program to Reverse a Given Number'''
#a=1234
#print(a)
#b=str(a)
#print(b[::-1])


'''let int 123 after reverse 321   LOGIC
123%10=3
12%10=2    (next dgt num//10)
1%10=1
3*10=30,  30+2=32  (32=3*10+2),  32*10=320,  320+1=321   (321=32*10+1 ==  rev=rev*10+rem)'''

#num=int(input('Enter a number'))
#rev=0
#while(num>0):
#    rem=num%10
#    rev=rev*10+rem
#    num=num//10
#print('After reverse a given num: ',rev)   


'''python program to check whether a number is positive or negative'''
#n=int(input('enter a number')) 
#if n>=0:
#    print('number is positive')
#else:
#    print('number is negative ')    
#    

'''6. Python Program to Take in the Marks of 5 Subjects and Display the Grade'''
#
#print('enter marks obtain in 5 subject')
#mark1=input()
#mark1=int(mark1)
#mark2=int(input())
#mark3=int(input())
#mark4=int(input())
#mark5=int(input())
#sum=mark1+mark2+mark3+mark4+mark5
#avg=sum/5
#if avg>=91 and avg<=100:
#    print('You Achieved grade:- A++')
#elif avg>=81 and avg<=90:
#    print('you Achieved grade:- A') 
#elif avg>=71 and avg<=80:
#    print('you Achieved grade:- B') 
#elif avg>=61 and avg<=70:
#    print('you Achieved grade:- c') 
#elif avg>=51 and avg<=60:
#    print('you Achieved grade:- D')
#elif avg>=41 and avg<=50:
#    print('you Achieved grade:- E')
#elif avg>=30 and avg<=40:
#    print('you Achieved grade:- F')    
#else:
#    print('Fail')
#     
'''7. Python Program to Print all Numbers in a Range Divisible by a Given Number'''
#
#lower=int(input('enter lower range limit: '))
#upper=int(input('enter upper range limit: '))
#n=int(input('enter no to be devide: '))
#print('Divisible by',n,':-')
#for i in range(lower,upper+1):
#    if i%n==0:
#        print(i)
           
'''Python Program to read two number and print their quotient and remender'''

#a=int(input('enter 1st no: '))
#b=int(input('enter 2nd no: '))
#q=a//b
#r=a%b
#print('Quotient: ',q)
#print('Remende: ',r)
#     
'''Pyhotn program to accept three digit and print all possible combination from this digit'''
#
#a=int(input('enter 1st no: '))
#b=int(input('enter 2nd no: '))
#c=int(input('enter 3rd no: '))
#list=[]
#list.append(a)
#list.append(b)
#list.append(c)
#for i in range(0,3):
#    for j in range(0,3):
#        for k in range(0,3):
#            if(i!=j & j!=k & k!=i):
#                print(list[i],list[j],list[k])



#
#a=int(input('enter 1st no: '))
#b=int(input('enter 2nd no: '))
#c=int(input('enter 3rd no: '))
#d=int(input('enter 4th no: '))
#list=[]
#list.append(a)
#list.append(b)
#list.append(c)
#list.append(d)
#for i in range(0,4):
#    for j in range(0,4):
#        for k in range(0,4):
#            for l in range(0,4):
#                if(i!=j & j!=k & k!=l & l!=i):
#                    print(list[i],list[j],list[k],list[l])


'''10. Python Program to Print Odd Numbers Within a Given Range'''
#a=int(input('enter 1st no: '))            
#b=int(input('enter 2nd no: '))
#for i in range(a,b):
#    if(i%2!=0):
#        print(i)
'''11. Python Program to Find the Sum of Digits in a Number'''

'''LOGIC:- input (123)>>Digit(1   2  3)>>sum of digit>>result
#n%10=rem(digit), res=0  res=res+digit  (ie 123%10=3 .... 3=0+3,  for remove 3 >>>123//10=12
# now 12%10=2>>>>2+3=5,   12//10=1 ......1%10=1     >>>5+1=6   1//10=0  cond repet so use loop '''

#n=int(input('enter positive integers: '))
#n=123456789
#sum=0
#while n>0:
#    digit=n%10
#    sum=sum+digit
#    n=n//10
#print('Sum of digits is:- ',sum)

'''12. Python Program to Find the Smallest Divisor of an Integer'''

#n=int(input('enter an integer: '))
#list=[]
#for i in range(2,n):
#    if(n%i==0):
#        list.append(i)
#        
#list.sort()
#print('Smallest diviser of given integer is:',list[0])

'''13. Python Program to Count the Number of Digits in a Number'''
#n=int(input('enter number: '))
#count=0
#while n>0:
#    
#    n=n//10
#    count+=1
#
#print('no of digit is: ',count)
#    
#    
    
'''*** 14. Python Program to Check if a Number is a Palindrome***1234321***'''
#A NUMBER IS SAID TO BE PALINDROM NUMBER IF ITS REVERSE IS SAME

#n=int(input('enter no:'))
#temp=n  
#rev=0
#while n>0:
#    rem=n%10
#    rev=rev*10+rem
#    n=n//10
#if(temp==rev):
#    print('Palindrom') 
#else:
#    print('Not Palindrom')    


'''16. Python Program to Read a Number n And Print the Series "1+2+…..+n= "'''
#n=int(input('enter no:'))
#sum=0
#for i in range(1,n+1):
#    sum+=i
#    print(i, end="+")
#print("\b", end="")
#print(" =",sum)
#    
#    
'''18. Python Program to Print an Identity Matrix'''

#n=int(input('enter a no: '))
#for i in range(n):
#    for j in range(n):
#        if i==j:
#            print('1',sep=' ',end=' ')
#        else: 
#            print('0',sep=' ',end=' ')
#    print(' ')       
# 
#    
'''Python Program to Print an Inverted Star Pattern'''
#n=int(input('enter no:'))
#for i in range(n,0,-1):
#    for j in range(0,i):
#        print("*",end=' ')
#    print()

   
'''Python Program to print simple interest Given all the Required values'''
#p=int(input('enter principle: '))
#r=int(input('enter rate in percent: ' ))
#t=int(input('enter time in year: '))
#si=(p*r*t)/100
#print(si)