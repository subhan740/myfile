'''PRACTICES PATTERN PROGRM'''

#def diamond(raws):
#    for i in range(raws):
#        print(' '*(raws-i-1)+'* '*(i+1))
#    for j in range(raws-1,0,-1):
#        print(' '*(raws-j)+'* '*(j))

#
#y=int(input('enter a year:'))
#if y%4==0:
#    if y%100==0:
#        if y%400==0:
#            print('{0} is  leap yr'.format(y))
#        else:
#            print('{0} is not a leap yr'.format%(y))
#    else:
#        print('{0} is a leap yr'.format(y))
#else:
#    print('{0} is not leap yr'.format(y))
#

        
#n=int(input('enter a no:'))  
#if n>1:
#    for i in range(2,n):
#        if n%i==0:
#            print('not prime',n)
#            break
#    else:
#        print('prime',n)
        

#    
#raws=int(input('enter no of raws: '))
#for i in range(raws):
#    print(' '*(raws-i-1)+'* '*(i+1))
#for j in range(raws-1,0,-1):
#    print(' '*(raws-j)+'* '*(j))
#        
        

#n=int(input('enter the no of side:'))
#for i in range(n,0,-1):
#    for j in range(0,i):
#        print("*",end=" ")
#    print()    
#        

#printing  A shape

#for i in range(7):
#    for j in range(5):
#        if ((j==0 or j==4) and i!=0) or ((i==0 or i==3) and (j>0 and j<4)):
#            print("*",end=" ")
#        else:
#            print(end="  ")
#    print()        
#        


#PRINTING B sHAPES
#for raw in range(7):
#    for col in range(5):
#        if(col==0)or ((col==4)and(raw!=0 and raw!=3 and raw!=6))or((raw==0 or raw==3 or raw==6)and(col>0 and col<4)):
#            print("*",end=" ")
#        else:
#            print(end="  ")
#    print()

#PRINTING C PATTERN

#for raw in range(7):
#    for col in range(5):
#        if (col==0) or ((raw==0 or raw==6)and (col>0)):
#            print('*',end=" ")
#        else:
#            print(end=" ")
#    print()            
#        
        
    
# PRINTING D SHAPE PATTERN

#for raw in range(7):
#    for col in range(5):
#        if(col==0)or ((col==4)and(raw!=0 and raw!=6))or (raw==0 or raw==6)and(col>0 and col<4):
#            print('*',end=" ")
#        else:
#            print(end="  ")
#    print() 


#PRINTING K SHAPE PATTERN
#for raw in range(7):
#    for col in range(5):
#        if(col==0)or (raw==3 and col==1)or((raw==2 or raw==4)and col==2)or ((raw==1 or raw==5)and col==3)or((raw==0 or raw==6)and(col==4)):
#            print('*',end=" ")
#        else:
#            print(end="  ")
#    print()       
  
#PRINTING M SHAPE PATTERN 
#for raw in range(7):
#    for col in range(5):
#        if (col==0 or col==4)or (raw==col)and(raw<3)or (raw==1 and col==3):
#            print("*",end="  ")
#        else:
#            print(end="   ")
#    print()  
      
#printing R shape pattern

#for raw in range(7):
#    for col in range(5):
#        if(col==0)or(raw==0 or raw==3)or(col==4)and(raw>0 and raw<3)or(raw==col+3):
#            print("*",end=" ")
#        else:
#            print(end="  ")
#    print()        


#for raw in range(7):
#    for col in range(5): 
#        if(col==0)or((raw==0 or raw==3)and(col!=4))or(col==4)and(raw>0 and raw<3)or(raw==col+3):
#            print("*",end=" ")
#        else:
#            print(end="  ")
#    print()        

 

      
   
    