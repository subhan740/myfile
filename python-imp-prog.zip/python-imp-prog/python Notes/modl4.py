
'''MODULEs'''
#
#def add(a,b):
#    return a+b
#
#def reverse(a):
#    return a[::-1]
#
#def sub(a,b):
#    return a-b
#
#def mul(a,b):
#    return a*b
#
#def div(a,b):
#    return a/b
#
#def fib(a,b,c):
#    x=[]
#    for i in range(c):
#        x.append(a)
#        a,b=b,a+b
#    return x
#           
#// this module is called by callmodel.py   


