'''1). WAp in python to  reverse String by using 1. slice operator, 2. reverse function , 3. while loop '''
#s='subhan khan'
#print(s[::-1])
#
#output=(s.upper()[::-1])
#print(output)

#r=reversed(s)

#for ch in r:
#    print(ch)

#r=reversed(s)
#output=''.join(r)
#print(output)
    
'''2). WAP in python to reverse order of words present in the given string '''

#method : given string can be devide into list of word/token using s.split() , no arg can be passed

#s=input('enter a string word to reverse: ')
#l=s.split()
#print(l)
#l1=l[::-1]
#print(l1)

##.join() func  join all whole separated word into a single word and ' ' provide space
#s=input('enter a string word to reverse: ')
#l=s.split()
#print(l)
#l1=l[::-1]
#l2=' '.join(l1)
#print(l2)

'''3). WAP in python to reverse internal content of each word'''
#
#s=input('enter some string word to rverse content of word:')
#l=s.split()
#print(l)
#list=[]
#for word in l:
#    list.append(word[::-1])    
#print(list) 
#
#
#output=' '.join(list)
#print(output)   


'''4). WAP in python to reverse internal content of every second word present in the given string'''
#s=input('enter some string word to reverse every second word: ')
#l=s.split()
#l1=[]
#for i in range(len(l)):
#    
#    if i%2==0:
#        l1.append(l[i])
#    else:
#        l1.append(l[i][::-1])
#output=' '.join(l1)        
#print(output)        

########## OR ******************************
#i=0
#l1=[]
#while i<len(l):
#    if i%2==0:
#        l1.append(l[i])
#    else:
#        l1.append(l[i][::-1])
#    i+=1
#print(l1) 
#
#
#opt=' '.join(l1)
#print(opt)   

'''5) write a program to print character present at even and odd index for the given string'''
#
#s='subhankhan'
#print('even position char:-')
#l1=[]
#l2=[]
#for i in range(len(s)):
#    if i%2==0:
#        l1.append(s[i])
#    else: 
#        l2.append(s[i])
#output1=' '.join(l1)
#output2=' '.join(l2)        
#print(output1)
#print('odd position character:')
#print(output2)    


######## OORRRRR*********************************************
#s='subhankhan'    
#print('character present at even index are:-')
#i=0
#while i<len(s):
#    print(s[i])
#    i+=2
#
#print('character present at odd index are:-')
#i=1
#while i<len(s):
#    print(s[i])
#    i+=2

#OR without loop or condition by using slice operator   
#s='subhankhan'
#print('character present at even index are:-',s[::2])
#print('character present at odd index are:-',s[1::2])

'''6) write a program to merge characters of two string into a single string by taking character alternatively'''
        
        
#s1=input('enter 1st string:')
#s2=input('enter 2nd string:')
#i,j=0,0
#output=''
#while i<len(s1) or j<len(s2):
#    if i<len(s1):
#        output=output+s1[i]
#        i=i+1
#    if j<len(s2):
#        output=output+s2[j]
#        j=j+1
#print(output)        
        
        
'''7) write the program for the following requirement(alphabet symbol followed by digit)
s='a4b3c5d2'
output=aaaabbbcccccdd'''


#s='a4b3c5d2'
#output=''
#for ch in s:
#    if ch.isalpha():
#        x=ch
#    else:
#        d=int(ch)
#        output=output+x*d
#print(output)        

'''7) write the program for the following requirement(alphabet symbol followed by digit)
s='aaaabbbcccccdd'
output=4a3b5c2d'''

#s='aaaabbbcccccdd'
#previous=s[0]             #######1st index value
#output=''
#c=1                         #counter
#i=1                       #2nd index value bcz 1st taken as s[0]
#while i<len(s):
#    if s[i]==previous:
#        c=c+1
#    else:
#        output+=str(c)+previous
#        previous=s[i]
#        c=1
#    if i==len(s)-1:
#         output+=str(c)+previous
#    i=i+1
#print(output)

'''Assume i/p string contains only alphabet symbols and digit(ie. alphanumeric) write a program to sort characters 
of the string first alphabet symbols followed by digits
eg ip: b4a1d3    opt: abd123'''

#s=input('enter some alphanumeric string to sort')
#alphabets=[]
#digits=[]
#for ch in s:
#    if ch.isalpha():
#        alphabets.append(ch)
#    else:
#        digits.append(ch)
#output=''.join(sorted(alphabets)+sorted(digits))   
#print(output)     
#         
'''program to remove duplicate charcter from the string'''

#s=input('enter string as you wish:')
#output=''
#for ch in s:
#    if ch not in output:       #if ch not already added in outout
#        output+=ch
#print(output)        
# 
#ORRR

#s=input('enter any string')
#l=[]
#for ch in s:
#    if ch not in l:
#        l.append(ch)
#print(l)
#opt=''.join(l)
#print(opt)           
#  

'''ARRAY IN PYTHON 

Array is similar to list  but one diffarence is that array is collectin of same type of value (if int all value sd int)
An advantage of arrays in python is that they don't have spacific size/fixed size which means it is flexible
which can srink and expand '''

#from array import *
#vals=array('i',[5,9,8,4,2])
#print(vals)
#
#vals.reverse()
#print(vals)
#     
#
#for i in range(5):
#    print(vals[i])
    


'''Print an array while values entering from the user and sarch the values and print index values'''
#
#from array import *
#arr=array('i',[])
#n=int(input('enter the length of the array'))
#for i in range(n):
#    x=int(input('enter the next values'))
#    arr.append(x)
#print(arr)
#val=int(input('enter values for search:'))
#
#k=0
#for e in arr:
#    if e==val:
#        print('Index value:',k)
#        break
#    k=k+1 
#    
##ORR
#
#print('Index value',arr.index(val))    
#    
    
'''PRINT only vowels from the given word'''

#a=input('enter words as u wish: ')
#for i in a:
#    if i in 'aeiouAEIOU':
#        print(i)
   
#
##   
#s=input('enter words as u wish: ')
#for a in s:
#    if (a=='a'or a=='e' or a=='i'or a=='o'or a=='u'):
#        print(a)
#        
   
'''Python Program to Count Vowels and Consonants in a String '''           
   
#str=input('enter string as you wish:')
#vowel=0
#consonant=0
#for i in str:
#    if i in 'aeiouAEIOU':
#        vowel+=1
#    else:
#        consonant+=1
#print('no of vowels :',vowel)
#print('no of consonant in the given string:',consonant)
    
'''PYTHON PROGRAM TO REMOVE VOWELS FROM A  STRING/to print consonant'''

#a=input('enter words as u wish: ')
#for i in a:
#    if i not in 'aeiouAEIOU':
#        print(i)
   
             
   
            

 