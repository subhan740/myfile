#TO PRINT LEAP YEAR

#y=int(input('enter a year:'))
#if y%4==0:
#    if y%100==0:
#        if y%400==0:
#            print('{0} is  leap yr'.format(y))
#        else:
#            print('{0} is not a leap yr'.format%(y))
#    else:
#        print('{0} is a leap yr'.format(y))
#else:
#    print('{0} is not leap yr'.format(y))


#Prime no prog
       
#n=int(input('enter a no:'))  
#if n>1:
#    for i in range(2,n):
#        if n%i==0:
#            print('not prime',n)
#            break
#    else:
#        print('prime',n)
#      
#

#Python Program to Print all Prime Numbers between an Interval
#a=int(input('enter lower range:'))
#b=int(input('enter upper range:'))
#for n in range(a,b+1):
#    if n>1:
#        for i in range(2,n):
#            if n%i==0:
#               
#                break
#        else:
#            print(n)


#Python Program to Find the Factorial of a Number

#n=int(input('enter a no:'))
#fact=1
#if n<0:
#    print('sorry fact does not exist of -ve no')
#elif n==0:
#    print('fact of 0 is :1') 
#elif n>1:
#    for i in range(2,n+1):
#        fact=fact*i
#print(fact)


## Python Program to Print the Fibonacci sequence

#n=int(input('enter no of term u want:'))
#a,b=0,1
#for i in range(n):
#    print(a)
#    a,b=b,a+b


##Python Program to Check Armstrong Number 
##Armstrong number:
#
##A number is called Armstrong number if it is equal to the sum of the cubes of its own digits.
##
##For example: 153 is an Armstrong number since 153 = 1*1*1 + 5*5*5 + 3*3*3.
#
#n=int(input('enter numbers: '))
#sum=0
#temp=n
#while temp>0:
#    digit=temp%10
#    sum+=digit**3
#    temp//=10
#if n==sum:
#    print('armangstrom no')
#else:
#    print('not arm angstrom no')    


##Python Program to Check Armstrong Number in an interval

#lower=int(input('enter lower limit: '))
#upper=int(input('enter upper limit : '))
#for n in range(lower,upper+1):
#    sum=0
#    temp=n
#    while temp>0:
#        digit=temp%10
#        sum+=digit**3
#        temp//=10
#        if n==sum:
#            print(n)
#         

 
##Python Program to Find the Sum of Natural Numbers   
#num = int(input("Enter a number: "))  
#  
#if num < 0:  
#   print("Enter a positive number")  
#else:  
#   sum = 0  
#   # use while loop to iterate un till zero  
#   while(num > 0):  
#       sum += num  
#       num -= 1  
#   print("The sum is",sum)  


#n=int(input('enter a no:'))
#if n%2==0:
#    print('plz enter odd int:')
#else:
#    for i in range(n):
#        for j in range(2*n+2):
#            if()


Input=[1,4,7,9,1,3,5,10,11]
Input.sort()    
list=[]
for i in range(len(Input)//2):
    list.append(Input[i])   
    list.append(Input[-i -1])    
if len(Input)%2:
    list.append(len(Input)//2)   
print(list)