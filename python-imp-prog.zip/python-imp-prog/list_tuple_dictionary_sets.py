
'''prog to Adding Element to the list by user '''
#
#n=int(input("Enter no of elements in the list: "))
#l=[]
#for i in range(0,n):
#    l.append(input("Enter the item? "))
#print("printing the list items....")
#print(l)
#for i in l:
#    print(i,end=" ")    

#####REMOVING/DELETING ELEMENT from the list
#list=[0,1,2,3,4,5,9,8]
#del(list[1])
#print('after deleting: ',list)
# 
#list.remove(9)
#print('after removing by direct item:',list)

############SEE ALL METHOD OF LIST IN JAVATPOINT 