'''5. Python Programming Questions on Dictionary'''
'''================================================================================================='''
'''1. Python Program to Add a Key-Value Pair to the Dictionary'''
#
# key=input('enter key to be added: ')
# value=input('enter value of key to be added: ')
# dict={}
# dict.update({key:value})
# print('updated key value is: ',dict)


'''2. Python Program to Concatenate Two Dictionaries Into One'''

#d1={'A':1,'D':7,'C':3}
#d2={'name':'suhan','roll no':'a1','branch':'cse'}
#d1.update(d2)
#print('concatention dict: ',d1)
#print(sorted(d1.values()))

'''3. Python Program to Check if a Given Key Exists in a Dictionary or Not'''

#d={'A':1,'B':2,'C':3}
#key=input('enter key value to check if key is present or not: ')
#if key in d.keys():
#    print('given keys exist in the dictionary and value of the key is: ',d[key])
#else:
#    print('key is not present in the dictionary!')    

'''4.With a given integral number n, write a program to generate a dictionary that
 contains (i, i*i) such that input 8 then output  {1: 1, 2: 4, 3: 9, 4: 16, 5: 25, 6: 36, 7: 49, 8: 64}'''
#
#n=int(input("enter a no: "))
#d={}
#for i in range(1,n+1):
#    d.update({i:i*i})
#print("Generated dictionary: ",d)    

'''5. Python Program to Sum All the Items in a Dictionary'''

# dict={'A':100,'B':200,'C':300,'D':400}
# print('sum of all the item in teh dictionary: ')
# print(sum(dict.values()))

'''OR'''
#dict={'A':100,'B':200,'C':300,'D':400,'E':500}
#sum=0
#for i in dict:
#    sum=sum+dict[i]
#print('sum of all the item in the dictionary: ')
#print(sum)

'''6. Python Program to Multiply All the Items in a Dictionary'''
# dict={'A':100,'B':200,'C':300,'D':400}
# mult=1
# for i in dict:
#    mult=mult*dict[i]
# print('multiple of all the item in teh dictionary: ')
# print(mult)


'''7. Python Program to Remove the Given Key from a Dictionary'''

# d={'name':'subhan','Id':11,'job':'technical'}
# print('dictionary item',d)
# k=input('enter key,  you want to delete:')
# if k in d:
#    del d[k]
# else:
#    print('given key is not in dictionary:') 
# print('\nUpdated dictionary',d) 

'''8. program to sorting dict by key {convert dictionary to list and sort then
 convert list into dict
 (sort dict by key method)}'''
# 
# d={1:'C',4:'A',3:'B',2:'D'}
# list1=list(d.items())
# list1.sort()
# print(list1)
# print(dict(list1))

'''9.Sorting dictionary by value (very imp)'''
d={1:'B',3:'A',2:'C'}
#s=sorted(d,key=d.__getitem__)
#for k in s:
#    print("{}:{}".format(k,d[k]))

#
####OORRR
# for key,val in sorted(d.items(),key=lambda item:item[1]):
#    print("%s:%s"%(key,val))

'''10. Get the maximum and minimum value in a dictionary'''
#d={"C":200,"A":100,"B":600}
#print(max(d.values()))
#print(min(d.values()))

'''11. VVI  Remove duplicates from Dictionary'''

#
#student_data = {'id1': 
#   {'name': ['Sara'], 
#    'class': ['V'], 
#    'subject_integration': ['english, math, science']
#   },
# 'id2': 
#  {'name': ['David'], 
#    'class': ['V'], 
#    'subject_integration': ['english, math, science']
#   },
# 'id3': 
#    {'name': ['Sara'], 
#    'class': ['V'], 
#    'subject_integration': ['english, math, science']
#   },
# 'id4': 
#   {'name': ['Surya'], 
#    'class': ['V'], 
#    'subject_integration': ['english, math, science']
#   },
#}
#
#result = {}
#
#for key,value in student_data.items():
#    if value not in result.values():
#        result[key] = value
#        
#for i in result.items():
#    
#    print(i)


'''12.  Check a dictionary is empty or not'''
#d={}
#if not bool(d):
#    print("dictionary is empty...")


'''13.  Combine two dictionary adding values for common keys'''
#from collections import Counter
#d1 = {'a': 100, 'b': 200, 'c':300}
#d2 = {'a': 300, 'b': 200, 'd':400}
#d = Counter(d1) + Counter(d2)
#print(d)

'''14. Sort a list alphabetically in a dictionary'''
#num = {'n1': [2, 3, 1], 'n2': [5, 1, 2], 'n3': [3, 2, 4]}
#sorted_dict = {x: sorted(y) for x, y in num.items()}
#print(sorted_dict)

'''15. Get the key, value and item in a dictionary'''
#
#d = {1: 10, 2: 20, 3: 30, 4: 40, 5: 50, 6: 60}
#print("key  value  count")
#for count, (key, value) in enumerate(d.items(), 1):
#    print(key,'   ',value,'    ', count)

'''16. Match key values in two dictionaries'''
#
#d1={1:'ABC',3:'BCD',4:'CDE'}
#d2={2:'EFG',3:'BCD',1:'ABC'}
#for (key,val) in (d1.items()) & (d2.items()):
#    print("%s:%s - is present in both d1 and d2"%(key,val))
