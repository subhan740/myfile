
'''REMOVE PUNCTUATION BY USING REGULAR EXPRESSION /WITHOUT LOOP in python'''
#METHOD   re.sub(pattern,replace,string)
'''In below code, we are substituting(re.sub) all NON[alphanumeric characters(\w) and
 spaces(\s)] with empty string.'''  

#import re
#s = "b/b/b/b/bbbnnn@!#$%^&*???...,,,"
#s = re.sub(r'[^\w\s]','',s)

#print(s)
 
#import re
#a="z/'/m\kk*%^#,.jjj,,.$&!//;;'']]hhhhk\/"
#b=re.sub(r'[^\w\s]','',a)
#print(b) 

####ORRR********IMP*********

#import re
#x = "hello!!! this is amazing? what."
#y = re.sub("[.,?!'\";:-]", "", x)
#print(y)

#import re
#x="hello ,this is .!!!&&^^%%$$subhan {(})[\|}/#&&**khan"
#y=re.sub("[^\w\s]","",x)

#print(y) #outputs "hello this is amazing what"


#import re
#s='b/baa/b/b*%%b/b/'
#print(re.sub("[/*%]","",s))

#
#s="b/b/b/b*b"
#s=s.replace('/','')  ###replace function apply to remove single punction or string
#print(s)

''' USING LOOP  REMOVE PUNCTUATION OR ANY CHARACTER FROM GIVEN STRING'''
#
# s="su/u\\\???***ub/ha/a//a/nDDD"
# for i in s:
#    if i in '/\?*':
#        s=s.replace(i,"")
# print(s)   

'''OORRR***********'''
#
#str = "py!@#$%thon"  
#for i in str:  
#    if i in 'ho!#$%':
#        continue;
#       
#    print(i); 
#


#str="s/s/s/s/u/b/h/a/n"
#str2=str.replace("/","")   ####replace only single word or single char or single punctuation
#print(str2)                 
                 
#     
   
'''print particular character from the given string'''

#s="suuuuubhankhann"
#print(s[1:6])

#    
#s="su/uub/ha/a//a/n"
#for i in s:
#    if i in '/au':
#        s=s.replace(i,"")
#print('after remove punc',s)

'''COUNT VOWELS/ ANY SPECIAL CHARACTER FROM GIVEN STRING'''

# s='subhan khan'
# count=0
# for vowel in s:
#    if vowel in 'aeiou':
#        count+=1
# print("No of vowels",count


'''FABONACCI SERIES'''
# a,b=0,1
# while a<10:
#    print(a,end=",")
#    a,b=b,a+b     


''' Write a program to check if a given string is a Palindrome.
A palindrome reads same from front and back e.g.- aba, ccaacc, mom, etc. '''
# a =input("Enter string to check palindrom :")
# #a[:] will give the whole string
# print(a[:])
# #a[::-1] -1 is step. It will reverse the string
# print(a[::-1])
# print(a == a[::-1])
# #There are lot of other ways to solve this problem

##############################
# s=input("enter a string")
# print(s)
# print(s[::-1])
# if(s==s[::-1]):
#     print('palindrom')
# else:
#     print('Not a paluindrom')
   
'''
1.
Write a program to find out the largest and smallest word in the string "This is an umbrella". '''

# s="This is an umbrella"
# s=s.split()
# print("original string after splitting:",s)
# maxx=s[0]
# max_len=len(s[0])
# for i in s:
#    if len(i)>max_len:
#        max_len=len(i)
#        maxx=i
# print("Largest word in the given string: ",maxx)
#        

#minn=s[0]
#min_len=len(s[0])
#for i in s:
#    if len(i)<min_len:
#        min_len=len(i)
#        minn=i
#print("smallest word: ",minn)

''' write the words in sorted assending and descending orde from the given sentence'''
#
#s="subhan ali khan lucky raj sultan hasina khatoon"
#s1=s.split()
#s1.sort()
#print(s1)
#
#output=" ".join(s1)
#print(output)
#s2=s1[::-1]
#print(s2)
#output2=" ".join(s2)
#print(output2)
   

'''Write a program to make a new string with the word "the" deleted 
in the sentence "This is the lion in the cage".'''


# s="This is the lion in the cage"
# s=s.split()
# for i in s:
#    if i =='the':
#        del(s[s.index(i)])
# print(" ".join(s))    

# #

'''
10.
Write a program to make a new string with all the consonents deleted 
from the string "Hello, have a good day". '''

# s="hello have a good day"
# for i in s:
#    if i not in 'aeiou':
#        print(i,end="")        



############OOORR
#a = ['a','e','i','o','u','A','E','I','O','U',' ']
#b = "Hello, have a good day"
#for i in b:
#  if i not in a:
#    b = b[:b.index(i)]+b[b.index(i)+1:]
#print (b)
#  

'''Write a program that takes your full name as input and displays the abbreviations
 of the first and middle names except the last name which is displayed as it is. 
For example, if your name is Robert Brett Roser, then the output should be R.B.Roser.'''
 
#a=input("enter string words: ")
##a = "Robert Brett Roser"
#a = a.split()
#b = a[0][0]+". "+a[1][0]+". "+a[2]
#print(b)

''' Write a Python program to change a given string to a new string where
 the first and last chars have been exchanged.'''
#
#def change_sring(str1):
#      return str1[-1:] + str1[1:-1] + str1[:1]
#	  
#print(change_sring('abcd'))
#print(change_sring('12345'))

'''Python: Reverse a string if it's length is a multiple of 4'''
#
# def reverse_string(str1):
#    if len(str1) % 4 == 0:
#        return ''.join(reversed(str1))
#    return str1
# print(reverse_string("abcd"))
# print(reverse_string(""))

'''python program to reverse internal content of each word'''
#
#s=input("Enter any string: ")
#l=s.split()
#l1=[]
#for i in l:
#    l1.append(i[::-1])
#print(' '.join(l1))    

'''write a program to reverse internal content of every second word in a string.'''

# s=input("enter a string: ")
# l=s.split()
# i=0
# l1=[]
# while i<len(l):
#    if i%2==0:
#        l1.append(l[i])
#    else:
#        l1.append(l[i][::-1])
#    i+=1    
# print(l1)   

'''program to print character present at even and odd index position'''

#s=input("Enter some string: ")
#print("character present at even index is:",s[0::2])
#print("character present at odd index is",s[1::2])

##OR
#s="subhankhan"
#print("the character present at even index: ")
#i=0
#while i<len(s):
#    print(s[i])
#    i+=2
#   
#i=1
#print("the character present at odd index: ")
#while i<len(s):
#    print(s[i])
#    i+=2     

'''python program to merge character of 2 strings into a single string by taking 
character alternate'''

# s1=input("enter first string: ")
# s2=input("enter second string: ")
# i,j=0,0
# output=''
# while i<len(s1) or j<len(s2):
#    if i<len(s1):
#        output+=s1[i]
#        i+=1
#    if j<len(s2):

#        output+=s2[j]
#        j+=1
# print(output)        

'''prog to sort character of string first alphabet symbol flowed by digit'''

#s=input("enter some alphanumeric string to sort: ")
#alphabets=[]
#digits=[]
#for ch in s:
#    if ch.isalpha():
#        alphabets.append(ch)
#    else:
#        digits.append(ch)
#output=''.join(sorted(alphabets)+sorted(digits))
#print(output)        
#        
'''prog for requirement input:a4b3c2 and expected output aaaabbbcc '''
#
#s=input("enter some string where alphabet symbol should followed by digit")
#output='' 
#for ch in s:
#    if ch.isalpha():
#        
#        x=ch
#    else:    
#        d=int(ch) ##convert digit which is str form to int digit
#        output+=x*d
#print(output) 


'''python program to print no of vowels and no of consonant in a string'''
#s=input("enter a string:")
#vowel=0
#consonant=0
#for i in s:
#    if i in 'aeiouAEIOU':
#        vowel+=1
#    else:
#        consonant+=1
#print("No of vowel present is: ",vowel)
#print("no of consonant present is:",consonant)        

################PATTERN PROGRAM
##Right angle triangle

# for i in range(0, 5):
#     for j in range(0, i+1):
#         print("* ",end="")
#     print()

#printing Odd * RAT

# a=1
# for i in range(0,5):
#     for j in range(0, a):
#         print("* ",end="")
#     a+=2
#     print()

'''print  STAR pattern as a hollow rhombus (Algoscale que i/p 1,2,3,5)'''    
#n=int(input('enter no of rows :'))
#for i in range(1,n+1):
#    for j in range(1,n-i+1):
#        print(end=" ")
#    if(i==1 or i==n):
#        for j in range(1,n+1):
#            
#            print("*",end="")
#    else:
#        for j in range(1,n+1):
#            if(j==1 or j==n):
#                print("*",end="")
#            else:
#                print(end=" ")
#    print()                
                
'''Print Hollow Rectangle star pattern'''

#rows=int(input('enter no of rows: '))
#cols=int(input('enter no of cols: '))
#print('Hollow rectangle star pattern')
#for i in range(rows):
#    for j in range(cols):
#        if(i == 0 or i == rows-1 or j == 0 or j == cols-1):
#            print('*',end =' ')
#        else:
#            print(' ',end =' ')
#    print()            
#            

'''pattern prog to print inverted triangle'''
#n = int(input('enter no: '))
#print('The required star pattern')
#
##for i in range(n,0,-1):
##    for k in range(n,i,-1):
##        print(' ',end='')
##    for j in range(1,i*2):
##        print('*',end='')
##    print()    
#    
#for i in range(n):
#    if i%2!=0:
#        print()
#    else:
#        print(' '*(n-i-1)+" *"*(i+1))


'''printing invert pyramid triangle pattern'''
#n = int(input('enter no: '))
#print('The required star pattern')
#
#    
#for i in range(n):
#    if i%2!=0:
#        print()
#    else:
#        print(' '*(n-i-1)+" *"*(i+1))
#
#    
#for j in range(i):
#    if j%2==0:
#        print()
#    else:    
#        print(' '*(j+1)+" *"*(i-j))
        

'''webkul pattern prog'''
#    
#rows=int(input('enter no of rows: '))
#for i in range(rows):
#    if i%2==0:
#        print(' '*(rows-i-1)+'* '*(i+1))
#    if 2*i+1==rows:
#        print(end="@"*(2*i+3))        
#for j in range(rows-1,0,-1):
#    if j%2!=0:
#        print(' '*(rows-j)+'* '*(j))


rows=int(input('enter no of rows: '))
for i in range(rows):
    if i%2==0:
        print(' '*(rows-i-1)+'* '*(i+1))        
for j in range(rows-1,0,-1):
    if j%2!=0:
        print(' '*(rows-j)+'* '*(j))

