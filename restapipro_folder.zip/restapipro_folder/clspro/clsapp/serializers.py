
from .models import Post, Comment
from rest_framework import serializers, generics


class CommentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Comment
        fields = ('user','is_Like','is_delete','comment_here', 'post','reply','creat_date')


class PostSerializer(serializers.ModelSerializer):
    class Meta:
        model = Post
        fields = ('user', 'title', 'Text', 'comment_set',)


