from django.db import models
from django.conf import settings
from django.utils import timezone
from django.contrib.auth.models import User
# class Post(models.Model):
#     title = models.CharField(max_length=200)
#     Text = models.TextField()

#     def __str__(self):
#         return self.title




class Post(models.Model):
    user = models.ForeignKey(User,default=0,on_delete=models.CASCADE)
    title = models.CharField(max_length=140)
    Text = models.TextField()
    is_Like=models.BooleanField(default=True)
    is_delete=models.BooleanField(default=False
    )

    # image = models.ImageField(upload_to =d
    # Image 		= models.ImageField(blank=True)
    # likes = models.ManyToManyField(settings.AUTH_USER_MODEL, blank=True, related_name='post_likes')               
    # likes = models.ManyToManyField(User,blank=True, related_name = 'post_likes')
    # height_field = models.IntegerField(default=0)
    # width_field = models.IntegerField(default=0)
    content = models.TextField()
    updated = models.DateTimeField(auto_now=True, auto_now_add=False)
    timestamp = models.DateTimeField(auto_now=False, auto_now_add=True)

def __unicode__(self):
    return self.title

def get_absolute_url(self):
    return reverse("posts:detail", kwargs={"id": self.id})

def get_api_like_url(self):
    return reverse("posts:like-api-toggle", kwargs={"id": self.id})

def get_like_url(self):
    return reverse("posts:like-toggle", kwargs={"id": self.id})



class Meta:
    ordering = ["-timestamp" , "-updated" ]





class Comment(models.Model):
    # user    = models.ForeignKey(settings.AUTH_USER_MODEL, default=1)
    post    = models.ForeignKey(Post,on_delete=models.CASCADE)
    user    = models.ForeignKey(User,on_delete=models.CASCADE)
    # likes = models.ManyToManyField(User,blank=True, related_name = 'post_likes')
    # likes_count   = models.IntegerField()
    is_Like=models.BooleanField(default=True)
    comment_here = models.TextField()
    reply   = models.ForeignKey('Comment', null=True, related_name="replies",on_delete=models.CASCADE)
    creat_date = models.DateTimeField(default=timezone.now)
    is_delete=models.BooleanField(default=False
    )


def __str__(set):
    return '{}-{}'.format(set.post.title,str(set.user.username))

# def get_like_url(self):
    # return reverse("posts:like-toggle", kwargs={"slug": self.slug})

# def get_api_like_url(self):
    # return reverse("posts:like-api-toggle", kwargs={"slug": self.slug})
