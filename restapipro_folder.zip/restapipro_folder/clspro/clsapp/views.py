from rest_framework import viewsets
from django.shortcuts import render, get_object_or_404, redirect
from rest_framework.permissions import AllowAny
from django.views.generic import RedirectView
from .models import Post, Comment
from .serializers import CommentSerializer, PostSerializer
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import authentication, permissions


class PostViewSet(viewsets.ModelViewSet):
    serializer_class = PostSerializer
    permission_classes = [AllowAny]
    queryset = Post.objects.all()


class CommentViewSet(viewsets.ModelViewSet):
    serializer_class = CommentSerializer
    permission_classes = [AllowAny]
    queryset = Comment.objects.all()


class PostLikeToggle(APIView):
    def get_redirect_url(self, *args, **kwargs):
        slug = self.kwargs.get("slug")
        obj = get_object_or_404(Post, slug=slug)
        url_ = obj.get_absolute_url()
        user = self.request.user 
        if user.is_authenticated():
            if user in obj.likes.all():
                obj.likes.remove(user)
            else:
                obj.likes.add(user)
        return url_



class PostLikeAPIToggle(APIView):

    serializer_class = PostSerializer
    permission_classes = [AllowAny]
    queryset = Post.objects.all()


    authentication_classes = (authentication.SessionAuthentication,)
    permission_classes = (permissions.IsAuthenticated,)

def get(self, request, id=None, format=None):
    obj = get_object_or_404(Post, id=id)
    url_ = obj.get_absolute_url() 
    user = self.request.user
    updated = False
    liked = False

    if user.is_authenticated():
        if user in obj.likes.all():
            liked = False
            obj.likes.remove(user)
        else:
            liked = True
            obj.likes.add(user)
        updated = True
    data = {
        "updated" : updated,
        "liked" : liked
    }
    return Response(data)











# class CommentListAPIView(ListAPIView):
#     serializer_class = CommentSerializer
#     filter_backends= [SearchFilter,OrderFilter]
#     search_fields = ['content','user__first_name']
#     pagination_class = PostPageNumberPagination

#     def get_queryset(self, *args, **kwargs):
#         queryset_list=Comment.objects.all()
#         query=self.request.GET.get("q")
#         if query:
#             queryset_list = queryset_list.filter(
#                 Q(content__icontains=query)|
#                 Q(user__first_name__icontains=query)|
#                 Q(user__last_name__icontains=query)|
#             ).distinct()

#         return queryset_list    


# from django.shortcuts import render
# from rest_framework import generics
# # Create your views here.
# from rest_framework.generics import CreateAPIView
# from clsapp.models import Comment
# from .serializers import CommentSerializer


# ''' API Endpoints '''
# class CommentCreate(generics.CreateAPIView):
#     queryset = Comment.objects.all()
#     serializer_class = CommentSerializer
    



#     def postdetail(request,id):
#         postt = get_object_or_404(post,id=id)
#         comments = Comment.objects.filter(post=postt,reply=None).order_by('-id')
#         is_liked = False
#         if postt.like.filter(id=request.user.id).exists():
#             is_liked = True
#         if request.method == 'POST':
#             comment_form = CommentForm(request.POST or None)
#             if comment_form.is_valid():
#                 content = request.POST.get('content')
#                 reply_id = request.POST.get('comment_id')
#                 comment_qs = None
#                 if reply_id:
#                     comment_qs = Comment.objects.get(id=reply_id)
#                 comment =  Comment.objects.create(post=postt,user=request.user,content=content,reply=comment_qs)
#                 comment.save()

#                 # return HttpResponseRedirect(postt.get_absolute_url())
#             else:
#                 comment_form = CommentForm()

#         context = {
#         'post': postt,
#         'is_liked': is_liked,
#         'total_likes':postt.total_likes(),
#         'comments':comments,
#         'comment_form':comment_form,
#         }
#         if request.is_ajax():
#             html = render_to_string('comments.html',context,request=request)
#             return JsonResponse({'form':html})

#         return render(request,'detail.html', context)


#     @classmethod
#     def get_extra_actions(cls):
#         return []