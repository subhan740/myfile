from django.apps import AppConfig


class ClsappConfig(AppConfig):
    name = 'clsapp'
