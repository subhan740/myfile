from django.contrib import admin

# Register your models here.

from .models import UnivStudent,User

admin.site.register(User)
admin.site.register(UnivStudent)
# admin.site.register(TemplateOwners)
