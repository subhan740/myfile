from django.shortcuts import render
from rest_framework.viewsets import ModelViewSet
# Create your views here.
from .serializers import *
from rest_framework import viewsets
from .models import UnivStudent

from .serializers import StudentSerializer

class StudentRecordViewSet(viewsets.ModelViewSet):
    queryset = UnivStudent.objects.all()
    serializer_class = StudentSerializer


