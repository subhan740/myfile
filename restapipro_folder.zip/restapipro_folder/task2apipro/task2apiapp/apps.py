from django.apps import AppConfig


class Task2ApiappConfig(AppConfig):
    name = 'task2apiapp'
