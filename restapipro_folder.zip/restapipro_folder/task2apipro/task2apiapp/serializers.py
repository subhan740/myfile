from rest_framework import serializers, status
from .models import *
from rest_framework.serializers import SerializerMethodField


class UserSerializer(serializers.ModelSerializer):
    # user = serializers.PrimaryKeyRelatedField(many=True, read_only=True)
    # id = serializers.IntegerField(required=False)
    class Meta:
        model = User
        fields = ('id', 'username', 'first_name','last_name', 'email','password',)
        # read_only_fields={email}

class StudentSerializer(serializers.ModelSerializer):

    username = SerializerMethodField()
    email = SerializerMethodField()

    """
    A student serializer to return the student details
    """
    # user = UserSerializer(many=True, required=False)
    user = UserSerializer(required=False,)


    class Meta:
        model = UnivStudent
        fields = ('id', 'user', 'address','zip','username','email',)

    def get_username(self, obj):
        return str(obj.user.username)

    def get_email(self, obj):
        return str((obj.user.email))    

    def create(self, validated_data):
        """
        Overriding the default create method of the Model serializer.
        :param validated_data: data containing all the details of student
        :return: returns a successfully created student record
        """
        user_data        = validated_data.pop('user')
        user             = UserSerializer.create(UserSerializer(), validated_data=user_data)
        student, created = UnivStudent.objects.update_or_create(user=user, address=validated_data.pop('address'),
        zip              = validated_data.pop('zip'))
        return student



    def update(self, instance, validated_data):
        user_data = validated_data.pop('user')
        # use = instance.user
        # use = list(use)
        instance.address = validated_data.get('address', instance.address)
        instance.zip = validated_data.get('zip', instance.zip)
        instance.save()

        for u_data in user_data:
            # ur = use.pop(0)
            ur.username =  u_data.get('username', ur.username)
            ur.first_name =  u_data.get('first_name', ur.first_name)
            ur.last_name =  u_data.get('last_name', ur.last_name)
            ur.email =  u_data.get('email', ur.email)
            ur.password =  u_data.get('password', ur.password)
            
            
            ur.save()
        return instance

        

    # def update(self, instance, validated_data):
    #     instance.user = validated_data.pop('user', instance.user)
    #     instance.address = validated_data.get('address', instance.address)
    #     instance.zip = validated_data.get('zip', instance.zip)
    #     instance.save()
    #     keep_user = []
    #     existing_ids = [c.id for c in instance.user]
    #     for u in user:
    #         if "id" in user.keys():
    #             if u.objects.filter(id=u["id"]).exists():
    #                 c=u.objects.get(id=u["id"])
    #                 c.text=u.get('text',c.text)
    #                 c.save()
    #                 keep_user.append(c)
    #             else:
    #                 continue
    #         else:
    #             c=u.objects.create(**u,student=instance)
    #             keep_user.append(c.id)  

    #     for u in instance.user:
    #         if u.id not in keep_user:
    #             u.delete() 
    #     return instance                     
        


       