from django.apps import AppConfig


class ShopmartConfig(AppConfig):
    name = 'shopmart'
