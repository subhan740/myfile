from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="ShopHome"),
    path("about/", views.about, name="AboutUs"),
    path("contact/", views.contact, name="ContactUs"),
    path("tracker/", views.tracker, name="TrackingStatus"),
    path("search/", views.search, name="Search"),
    path('signup/', views.signup, name="signup"),
    path("products/<int:myid>", views.productView, name="ProductView"),
    path("checkout/", views.checkout, name="Checkout"),
    path("handlerequest/", views.handlerequest, name="HandleRequest"),

]







# Paytm Test

# Mobile Number – 7777777777
# Password – Paytm12345
# OTP – 489871

# Credit Card Test
# 4111 1111 1111 1111
# 42222 2222 2222

# Debit card Test
# 4242 4242 4242 4242
# 11/23 123