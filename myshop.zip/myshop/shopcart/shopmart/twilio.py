from twilio.rest import Client


def send_sms(mobile,order):
 
    account_sid = "ACcb5df1a5e2487e60238a61c901564b7b"            #company details
    auth_token = "029bdb173395b26aea61ecec40adf3bb"
    client = Client(account_sid, auth_token)
    user_mobile = mobile
    message = client.messages.create(
        # to="+91"+user_mobile,
        to="+917906655160",
        from_="+12015483551", #Subhan Khan

        # from_="+18555728559",
        # from_="+17042702788", #--office
        body=" Your Order has been Placed.. Track Your Order in MyShoCart App. your Order No is: "+str(order))






###my twilio ph:-Your new Phone Number is +12015483551
###ACCOUNT SID  : ACcb5df1a5e2487e60238a61c901564b7b
###AUTH TOKEN : 2ce99f0c5c05c95d8e6533e39a4ebe10