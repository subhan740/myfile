from django.shortcuts import render, redirect
from .forms import CustomUserCreationForm
# from .forms import SignupForm
from django.contrib import messages
from .models import *
from django.contrib.auth.decorators import login_required

# Create your views here.

def home(request):
    return render(request, 'home.html', {})

# def user_registration(request):
#     form = SignupForm(request.POST or None, request.FILES or None)
#     if request.method == 'POST':
#         name = request.POST['first_name']
#         email = request.POST['email']
#         username = request.POST['username']
#         password1 = request.POST['password1']
#         password2 = request.POST['password2']
       
#         # form = SignupForm(name=name,email=email,username=username,password1=password1,password2=password2)
#         form.save()

#         return redirect('login')
#     else:
#         form = SignupForm
#         return render(request,'registration/registration.html')

def user_registration(request):
    form = CustomUserCreationForm(request.POST or None, request.FILES or None)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            messages.success(request, 'Successfully registered')
            return redirect('login')
    else:
        form = CustomUserCreationForm()        
        # If the request params is valid save the data else return form with error
    return render(request, 'registration/registration.html', {'form': form})

@login_required(login_url='/accounts/login')
def user_profile(request):
    return render(request, 'user_profile.html', {'user': request.user})





    

