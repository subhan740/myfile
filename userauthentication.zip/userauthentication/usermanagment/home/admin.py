from django.contrib import admin
# from home.models import Signup

# # Register your models here.
# admin.site.register(Signup)
