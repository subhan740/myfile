from django.shortcuts import render
from .models import Product

# Create your views here.
def search(request):
    s = Product.objects.all()
    # for i in s:
    #     v = i.country
        # print(var)

    return render(request,'searchapp/search.html',{'s':s})




# def questions2(request):
# #     print(choice)
#     quest = Questions2.objects.all()
#     for i in quest:
#             var=i.question2
#             print(var)
#     return render(request,
#         'quizapp/questions2.html',
#         {'quest':quest})
