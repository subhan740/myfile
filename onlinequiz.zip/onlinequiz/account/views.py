from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from account.forms import RegistrationForm, AccountAuthenticationForm, AccountUpdateForm
from django.contrib.auth import login as auth_login
from account.models import Account
from django.contrib import messages
from django.contrib.auth.models import User, auth
# Create your views here.



def register(request):
	context = {}
	if request.POST:
		form = RegistrationForm(request.POST)
		if form.is_valid():
			form.save()
			email = form.cleaned_data.get('email')
			raw_password = form.cleaned_data.get('password1')
			account = authenticate(email=email, password=raw_password)
			# auth.login(request, account)
			return redirect('login')
		else:
			context['registration_form'] = form

	else:
		form = RegistrationForm()
		context['registration_form'] = form
	return render(request, 'account/register.html', context)


def logout(request):
	auth.logout(request)
	return redirect('home')


def login(request):

	context = {}

	user = request.user
	if user.is_authenticated: 
		return redirect("home")

	if request.POST:
		form = AccountAuthenticationForm(request.POST)
		if form.is_valid():
			email = request.POST['email']
			password = request.POST['password']
			user = authenticate(email=email, password=password)

			if user is not None:
				auth.login(request, user)
				return redirect("home")

	else:
		form = AccountAuthenticationForm()

	context['login_form'] = form

	print(form)
	return render(request, "account/login.html", context)


# def login(request):
#     if request.method=="post":
#         username = request.POST['email']
#         password = request.POST['password']

#         user = authenticate(email=email,password=password)
#         if user is not None:
#             auth.login(request, user)
#             return redirect("/")
#         else:
#             messages.info(request,'invalid credentials')
#             return redirect('login')

#     else:
#         return render(request,'account/login.html')


