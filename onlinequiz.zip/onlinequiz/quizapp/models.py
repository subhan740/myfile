from django.db import models

# Create your models here.
class Questions(models.Model):
    CAT_CHOICES = (
    ('python','Python'),
    ('java','Java'),
    ('aptitude','Aptitude'),
    ('communication','Verbal')
    )
    question = models.CharField(max_length = 200)
    optiona = models.CharField(max_length = 50)
    optionb = models.CharField(max_length = 50)
    optionc = models.CharField(max_length = 50)
    optiond = models.CharField(max_length = 50)
    answer = models.CharField(max_length = 50)
    catagory = models.CharField(max_length=20, choices = CAT_CHOICES)

    class Meta:
        ordering = ('-catagory',)

    def __str__(self):
        return self.question

class Questions2(models.Model):
    question2 = models.CharField(max_length = 200)
    option1 = models.CharField(max_length = 20)
    option2 = models.CharField(max_length = 20)
    option3 = models.CharField(max_length = 20)
    option4 = models.CharField(max_length = 20)
    option5 = models.CharField(max_length = 20)
    option6 = models.CharField(max_length = 20)
    option7 = models.CharField(max_length = 20)
    option8 = models.CharField(max_length = 20)
    option9 = models.CharField(max_length = 20)
    option10 = models.CharField(max_length = 20)
   
    answer = models.CharField(max_length = 200)
   
    def __str__(self):
        return self.question2

