from django.urls import path
from . import views

urlpatterns = [
    path('',views.myhome, name="myhome"),
    path('home', views.home, name = 'home'),
    path('result', views.result, name = 'result'),
    path('select', views.select, name = 'select'),
    path('about', views.about, name = 'about'),
    path('contact', views.contact, name = 'contact'),
    path('questions2', views.questions2, name = 'questions2'),
    path('<choice>', views.questions, name = 'questions'),
    
]

