from django.contrib import admin

from .models import Questions,Questions2

# Register your models here.
admin.site.register(Questions)
admin.site.register(Questions2)
