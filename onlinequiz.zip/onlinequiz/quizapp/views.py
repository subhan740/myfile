from django.shortcuts import render

from .models import *

# Create your views here.
def myhome(request):
        return render(request,'quizapp/myhome.html')

def home(request):
    choices = Questions.CAT_CHOICES
    print(choices)
    return render(request,
        'quizapp/home.html',
        {'choices':choices})

def questions(request , choice):
    print(choice)
    ques = Questions.objects.filter(catagory__exact = choice)
    return render(request,
        'quizapp/questions.html',
        {'ques':ques})



def questions2(request):
#     print(choice)
    quest = Questions2.objects.all()
    for i in quest:
            var=i.question2
            print(var)
    return render(request,
        'quizapp/questions2.html',
        {'quest':quest})



def result(request):
    questions = Questions.objects.all()
    score = 0
    for question in questions:
	    correct_answer = question.answer 
	    entered_answer = request.POST.get(str(question.id)) 
	    if(entered_answer == correct_answer): 
		    score+=1 
    total=len(questions)  
    eff = (score/total)*100 

    return render(request,
        'quizapp/result.html',
         {'score':score,
        'eff':eff,
        'total':total})


def result2(request):
        # q = Questions2.objects.all('questions2')
        # for i in q:
        #         correct = i.answer 
                # entered_answer = request.POST.get(str(question2.id)) 
	# if(entered_answer == correct_answer): 
        
		
        return render(request,'quizapp/result2.html')


def about(request):
    return render(request,
        'quizapp/about.html')

def contact(request):
    return render(request,
        'quizapp/contact.html')


def select(request):
    pass




