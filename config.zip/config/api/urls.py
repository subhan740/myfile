from django.conf.urls import url, include
from rest_framework import routers
from api.views import UserViewSet

router = routers.DefaultRouter()
router.register(r'users', UserViewSet)

urlpatterns = [
    url(r'^', include(router.urls)),
    url(r'^auth/', include('rest_auth.urls')),
]












##http://127.0.0.1:8000/api/users/
##http://127.0.0.1:8000/api/auth/login/
##http://127.0.0.1:8000/api/auth/logout/