                                                            
                                                    // Defining a function to display error message
function printError(elemId, hintMsg) {
    document.getElementById(elemId).innerHTML = hintMsg;
}

// Defining a function to validate form 
function validateForm() {
    // Retrieving the values of form elements 
    var name = document.contactForm.name.value;
    var email = document.contactForm.email.value;
    var mobile = document.contactForm.mobile.value;
    var password = document.contactForm.password.value;
    var password2 = document.contactForm.password2.value;
    var country = document.contactForm.country.value;
    var zipcode = document.contactForm.zipcode.value;
    var gender = document.contactForm.gender.value;
    
	// Defining error variables with a default value
    var nameErr = emailErr = mobileErr= passErr = pass2Err = countryErr = zipcodeErr = genderErr = true;
    
    // Validate name
    if(name == "") {
        printError("nameErr", "Please enter your name");
    } else {
       // var regex = /^[a-zA-Z\s]+$/;   
       var regex = /^[^ \t\n\r][a-zA-Z ]{2,30}$/;             
        if(regex.test(name) === false) {
            printError("nameErr", "Please enter a valid name");
        } else {
            printError("nameErr", "");
            nameErr = false;
        }
    }
    
    // Validate email address
    if(email == "") {
        printError("emailErr", "Please enter your email address");
    } else {
        // Regular expression for basic email validation
        //var regex = /^\S+@\S+\.\S+$/;
        var regex = /^([a-zA-Z0-9\.-]+)@([a-z0-9-]+).([a-z]{2,8})(.[a-z]{2,8})?$/;
        if(regex.test(email) === false) {
            printError("emailErr", "Please enter a valid email address");
        } else{
            printError("emailErr", "");
            emailErr = false;
        }
    }
    
    // Validate mobile number
    if(mobile == "") {
        printError("mobileErr", "Please enter your mobile number");
    } else {
        var regex = /^[1-9]\d{9}$/;
        if(regex.test(mobile) === false) {
            printError("mobileErr", "Please enter a valid 10 digit mobile number");
        } else{
            printError("mobileErr", "");
            mobileErr = false;
        }
    }

    //validation password
   
    if(password == "") {
        printError("passErr", "Please enter your password ");
       
        $("#password").password("toggle")
    } else {
        var regex = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;
        if(regex.test(password) === false) {
            printError("passErr", "Please enter a valid password /password must contain atleast a digit & special character");
        } else{
            printError("passErr", "");
            passErr = false;
        }
    }

   

    if(password != password2.match(regex)){
        printError("pass2Err", "password & confirm password must be same");
        $("#password2").password("toggle")
    }else{
        printError("pass2Err", "");
        pass2Err = false;
    }
    
    if(password2 == ""){
        printError("pass2Err" ,"plz enter your confirm password")
      }else{
        printError("passErr", "");
        passErr = false;
    }


    // Validate country
    if(country == "Select") {
        printError("countryErr", "Please select your country");
    } else {
        printError("countryErr", "");
        countryErr = false;
    }
    

    //validate ZIP code
    if(zipcode == "") {
        printError("zipcodeErr", "Please enter your 4/5/6 digit zip code");
    } else {
        var regex = /^[0-9]\d{4,6}$/;
        if(regex.test(zipcode) === false) {
            printError("zipcodeErr", "Please enter  valid zip code");
        } else{
            printError("zipcodeErr", "");
            zipcodeErr = false;
        }
    }
 
   
    // Validate gender
    if(gender == "") {
        printError("genderErr", "Please select your gender");
    } else {
        printError("genderErr", "");
        genderErr = false;
    }
    
    // Prevent the form from being submitted if there are any errors
    if((nameErr || emailErr || mobileErr|| passErr || pass2Err || countryErr || zipcodeErr || genderErr) == true) {
       return false;
    } else {
        // Creating a string from input data for preview
        var dataPreview = "You've entered the following details: \n" +
                          "Full Name: " + name + "\n" +
                          "Email Address: " + email + "\n" +
                          "Mobile Number: " + mobile + "\n" +
                          "Country: " + country + "\n" +
                          "zipcode: " + zipcode + "\n" +
                          "Gender: " + gender + "\n";
        
        // Display input data in a dialog box before submitting the form
        confirm(dataPreview);
    }
};
