from django.apps import AppConfig


class AutosearchbarConfig(AppConfig):
    name = 'autosearchbar'
